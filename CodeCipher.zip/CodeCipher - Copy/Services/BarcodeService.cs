using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using ZXing;
using ZXing.Common;
using ZXing.Windows.Compatibility;

namespace CodeCipher.Services
{
    public enum LabelPosition
    {
        Bottom,
        Top,
        None
    }

    public class BarcodeOptions
    {
        public string Content { get; set; } = string.Empty;
        public BarcodeFormat Format { get; set; } = BarcodeFormat.CODE_39;
        public int Width { get; set; } = 350;
        public int Height { get; set; } = 150;
        public int Margin { get; set; } = 10;
        public bool IncludeLabel { get; set; } = true;
        public LabelPosition TextPosition { get; set; } = LabelPosition.Bottom;
        public bool IncludeBorder { get; set; } = true;
        public Color BorderColor { get; set; } = Color.Black;
        public int BorderThickness { get; set; } = 2;
        public int BorderPadding { get; set; } = 10;
        public Color ForeColor { get; set; } = Color.Black;
        public Color BackColor { get; set; } = Color.White;
        public Font LabelFont { get; set; } = new Font("Segoe UI", 10, FontStyle.Regular);
    }

    public class BarcodeService
    {
        public static readonly Dictionary<string, BarcodeFormat> SupportedFormats = new()
        {
            { "Code 39", BarcodeFormat.CODE_39 },
            { "Data Matrix (DM Code)", BarcodeFormat.DATA_MATRIX },
            { "QR Code", BarcodeFormat.QR_CODE }
        };

        public Bitmap GenerateBarcode(BarcodeOptions options)
        {
            if (string.IsNullOrWhiteSpace(options.Content))
            {
                throw new ArgumentException("Nội dung tạo mã không được để trống.");
            }

            bool hasText = options.IncludeLabel && options.TextPosition != LabelPosition.None;

            int targetWidth = Math.Max(50, options.Width);
            int targetHeight = Math.Max(50, options.Height);

            int textPadding = hasText ? 25 : 0;
            int barcodeHeight = Math.Max(20, targetHeight - textPadding);

            var writer = new BarcodeWriter
            {
                Format = options.Format,
                Options = new EncodingOptions
                {
                    Width = targetWidth,
                    Height = barcodeHeight,
                    Margin = 0,
                    PureBarcode = true
                }
            };

            Bitmap rawBitmap;
            try
            {
                rawBitmap = writer.Write(options.Content);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Không thể tạo mã vạch với nội dung đã nhập ({options.Format}): {ex.Message}", ex);
            }

            using (rawBitmap)
            {
                using var coloredBarcode = ColorizeBitmap(rawBitmap, options.ForeColor, options.BackColor);

                GetBarcodeContentBounds(coloredBarcode, options.ForeColor, out int minX, out int maxX);
                int barsWidth = maxX - minX + 1;

                int textWidth = 0;
                if (hasText)
                {
                    using var dummyBmp = new Bitmap(1, 1);
                    using var dummyG = Graphics.FromImage(dummyBmp);
                    SizeF sz = dummyG.MeasureString(options.Content, options.LabelFont);
                    textWidth = (int)Math.Ceiling(sz.Width);
                }

                int contentWidth = Math.Max(barsWidth, textWidth);
                int padding = Math.Max(0, options.BorderPadding);
                int finalWidth = contentWidth + (padding * 2);
                int finalHeight = barcodeHeight + textPadding + (padding * 2);

                var resultBitmap = new Bitmap(finalWidth, finalHeight);

                using (Graphics g = Graphics.FromImage(resultBitmap))
                {
                    g.Clear(options.BackColor);
                    g.SmoothingMode = SmoothingMode.None;
                    g.InterpolationMode = InterpolationMode.NearestNeighbor;

                    int barsX = padding + (contentWidth - barsWidth) / 2;
                    int barsY = padding + ((hasText && options.TextPosition == LabelPosition.Top) ? textPadding : 0);
                    int textY = (hasText && options.TextPosition == LabelPosition.Top) ? padding : (padding + barcodeHeight);

                    // Draw cropped barcode / 2D matrix
                    Rectangle srcRect = new Rectangle(minX, 0, barsWidth, rawBitmap.Height);
                    Rectangle destRect = new Rectangle(barsX, barsY, barsWidth, barcodeHeight);
                    g.DrawImage(coloredBarcode, destRect, srcRect, GraphicsUnit.Pixel);

                    // Draw text if enabled (for both 1D and 2D formats like Data Matrix & QR)
                    if (hasText)
                    {
                        g.SmoothingMode = SmoothingMode.AntiAlias;
                        using var brush = new SolidBrush(options.ForeColor);
                        using var stringFormat = new StringFormat
                        {
                            Alignment = StringAlignment.Center,
                            LineAlignment = StringAlignment.Center
                        };

                        Rectangle textRect = new Rectangle(padding, textY, contentWidth, textPadding);
                        g.DrawString(options.Content, options.LabelFont, brush, textRect, stringFormat);
                    }

                    // Draw outer border frame if enabled
                    if (options.IncludeBorder && options.BorderThickness > 0)
                    {
                        g.SmoothingMode = SmoothingMode.None;
                        using var pen = new Pen(options.BorderColor, options.BorderThickness)
                        {
                            Alignment = PenAlignment.Inset
                        };
                        g.DrawRectangle(pen, 0, 0, finalWidth - 1, finalHeight - 1);
                    }
                }

                return resultBitmap;
            }
        }

        private static void GetBarcodeContentBounds(Bitmap bitmap, Color foreColor, out int minX, out int maxX)
        {
            minX = 0;
            maxX = bitmap.Width - 1;

            var bitmapData = bitmap.LockBits(
                new Rectangle(0, 0, bitmap.Width, bitmap.Height),
                ImageLockMode.ReadOnly,
                PixelFormat.Format32bppArgb);

            try
            {
                unsafe
                {
                    byte* ptr = (byte*)bitmapData.Scan0;
                    int width = bitmap.Width;
                    int height = bitmap.Height;

                    bool found = false;
                    for (int x = 0; x < width; x++)
                    {
                        for (int y = 0; y < height; y++)
                        {
                            int idx = (y * width + x) * 4;
                            byte b = ptr[idx];
                            byte g = ptr[idx + 1];
                            byte r = ptr[idx + 2];
                            if (r < 128 && g < 128 && b < 128)
                            {
                                minX = x;
                                found = true;
                                break;
                            }
                        }
                        if (found) break;
                    }

                    found = false;
                    for (int x = width - 1; x >= 0; x--)
                    {
                        for (int y = 0; y < height; y++)
                        {
                            int idx = (y * width + x) * 4;
                            byte b = ptr[idx];
                            byte g = ptr[idx + 1];
                            byte r = ptr[idx + 2];
                            if (r < 128 && g < 128 && b < 128)
                            {
                                maxX = x;
                                found = true;
                                break;
                            }
                        }
                        if (found) break;
                    }
                }
            }
            finally
            {
                bitmap.UnlockBits(bitmapData);
            }

            if (minX > maxX)
            {
                minX = 0;
                maxX = bitmap.Width - 1;
            }
        }

        private static Bitmap ColorizeBitmap(Bitmap original, Color foreColor, Color backColor)
        {
            var bitmap = new Bitmap(original.Width, original.Height, PixelFormat.Format32bppArgb);
            var srcData = original.LockBits(new Rectangle(0, 0, original.Width, original.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            var destData = bitmap.LockBits(new Rectangle(0, 0, bitmap.Width, bitmap.Height), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);

            try
            {
                unsafe
                {
                    byte* srcPtr = (byte*)srcData.Scan0;
                    byte* destPtr = (byte*)destData.Scan0;
                    int totalPixels = original.Width * original.Height;

                    for (int i = 0; i < totalPixels; i++)
                    {
                        byte b = srcPtr[i * 4];
                        byte g = srcPtr[i * 4 + 1];
                        byte r = srcPtr[i * 4 + 2];

                        bool isForeground = (r < 128 && g < 128 && b < 128);
                        Color c = isForeground ? foreColor : backColor;

                        destPtr[i * 4] = c.B;
                        destPtr[i * 4 + 1] = c.G;
                        destPtr[i * 4 + 2] = c.R;
                        destPtr[i * 4 + 3] = c.A;
                    }
                }
            }
            finally
            {
                original.UnlockBits(srcData);
                bitmap.UnlockBits(destData);
            }

            return bitmap;
        }
    }
}
