using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace CodeCipher.Services
{
    public class BatchResult
    {
        public int TotalCount { get; set; }
        public int SuccessCount { get; set; }
        public int FailureCount { get; set; }
        public List<string> Errors { get; } = new();
        public string OutputDirectory { get; set; } = string.Empty;
    }

    public class BatchService
    {
        private readonly BarcodeService _barcodeService;

        public BatchService(BarcodeService barcodeService)
        {
            _barcodeService = barcodeService;
        }

        public BatchResult ProcessBatch(IEnumerable<string> contents, BarcodeOptions baseOptions, string outputFolder, string fileExtension = "png")
        {
            var result = new BatchResult { OutputDirectory = outputFolder };
            if (!Directory.Exists(outputFolder))
            {
                Directory.CreateDirectory(outputFolder);
            }

            ImageFormat format = fileExtension.ToLower() switch
            {
                "jpg" or "jpeg" => ImageFormat.Jpeg,
                "bmp" => ImageFormat.Bmp,
                "gif" => ImageFormat.Gif,
                _ => ImageFormat.Png
            };

            int index = 1;
            foreach (var rawLine in contents)
            {
                string text = rawLine.Trim();
                if (string.IsNullOrEmpty(text)) continue;

                result.TotalCount++;
                try
                {
                    var opt = new BarcodeOptions
                    {
                        Content = text,
                        Format = baseOptions.Format,
                        Width = baseOptions.Width,
                        Height = baseOptions.Height,
                        Margin = baseOptions.Margin,
                        IncludeLabel = baseOptions.IncludeLabel,
                        TextPosition = baseOptions.TextPosition,
                        IncludeBorder = baseOptions.IncludeBorder,
                        BorderThickness = baseOptions.BorderThickness,
                        BorderPadding = baseOptions.BorderPadding,
                        BorderColor = baseOptions.BorderColor,
                        ForeColor = baseOptions.ForeColor,
                        BackColor = baseOptions.BackColor,
                        LabelFont = baseOptions.LabelFont
                    };

                    using Bitmap bmp = _barcodeService.GenerateBarcode(opt);
                    
                    // Sanitize file name
                    string safeFileName = string.Join("_", text.Split(Path.GetInvalidFileNameChars()));
                    if (safeFileName.Length > 50) safeFileName = safeFileName.Substring(0, 50);
                    
                    string fileName = $"{index:D4}_{safeFileName}.{fileExtension.ToLower()}";
                    string fullPath = Path.Combine(outputFolder, fileName);

                    bmp.Save(fullPath, format);
                    result.SuccessCount++;
                }
                catch (Exception ex)
                {
                    result.FailureCount++;
                    result.Errors.Add($"Dòng {index} ('{text}'): {ex.Message}");
                }
                index++;
            }

            return result;
        }
    }
}
