using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace CodeCipher.Services
{
    public class ExportService
    {
        public static bool SaveImage(Image image, out string savedPath)
        {
            savedPath = string.Empty;
            using var sfd = new SaveFileDialog
            {
                Title = "Lưu mã vạch",
                Filter = "PNG Image (*.png)|*.png|JPEG Image (*.jpg)|*.jpg|Bitmap Image (*.bmp)|*.bmp|GIF Image (*.gif)|*.gif",
                DefaultExt = "png",
                AddExtension = true
            };

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                ImageFormat format = ImageFormat.Png;
                string ext = System.IO.Path.GetExtension(sfd.FileName).ToLower();
                switch (ext)
                {
                    case ".jpg":
                    case ".jpeg":
                        format = ImageFormat.Jpeg;
                        break;
                    case ".bmp":
                        format = ImageFormat.Bmp;
                        break;
                    case ".gif":
                        format = ImageFormat.Gif;
                        break;
                }

                image.Save(sfd.FileName, format);
                savedPath = sfd.FileName;
                return true;
            }

            return false;
        }

        public static bool CopyToClipboard(Image image)
        {
            try
            {
                Clipboard.SetImage(image);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void PrintImage(Bitmap bitmap, string title = "CodeCipher Barcode")
        {
            using PrintDocument pd = new PrintDocument();
            pd.DocumentName = title;
            pd.PrintPage += (sender, e) =>
            {
                if (e.Graphics != null && bitmap != null)
                {
                    // Center the barcode on page
                    float x = Math.Max(20, (e.PageBounds.Width - bitmap.Width) / 2f);
                    float y = Math.Max(20, (e.PageBounds.Height - bitmap.Height) / 2f);
                    e.Graphics.DrawImage(bitmap, x, y);
                }
            };

            using PrintDialog printDialog = new PrintDialog
            {
                Document = pd
            };

            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                pd.Print();
            }
        }
    }
}
