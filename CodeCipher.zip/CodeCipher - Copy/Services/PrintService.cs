using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace CodeCipher.Services
{
    public enum PaperType
    {
        A4,
        A5
    }

    public class PrintSettings
    {
        public PaperType Paper { get; set; } = PaperType.A4;
        public int Columns { get; set; } = 4;
        public int Rows { get; set; } = 8;
        public int Margin { get; set; } = 30; // 30 hundredths of an inch (~7.6mm)
        public bool ShowGridLines { get; set; } = true;
        public int CopiesPerItem { get; set; } = 1;
        public string DocName { get; set; } = "CodeCipher Barcode Print";
    }

    public class PrintService
    {
        public static PaperSize GetPaperSize(PaperType type)
        {
            return type switch
            {
                PaperType.A5 => new PaperSize("A5", 583, 827),
                _ => new PaperSize("A4", 827, 1169)
            };
        }

        public void PrintPreviewSingle(Bitmap barcodeBitmap, PrintSettings settings)
        {
            var list = new List<Bitmap>();
            int count = Math.Max(1, settings.CopiesPerItem);
            for (int i = 0; i < count; i++)
            {
                list.Add(barcodeBitmap);
            }

            settings.DocName = "In Xem Trước 1 Mã Vạch - CodeCipher";
            ShowPrintPreview(list, settings);
        }

        public void PrintDirectSingle(Bitmap barcodeBitmap, PrintSettings settings)
        {
            var list = new List<Bitmap>();
            int count = Math.Max(1, settings.CopiesPerItem);
            for (int i = 0; i < count; i++)
            {
                list.Add(barcodeBitmap);
            }

            settings.DocName = "In Trực Tiếp 1 Mã Vạch - CodeCipher";
            ShowPrinterSelectionDialog(list, settings);
        }

        public void ShowPrintPreview(List<Bitmap> barcodeBitmaps, PrintSettings settings)
        {
            if (barcodeBitmaps.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu mã vạch nào để in.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var pd = CreatePrintDocument(barcodeBitmaps, settings);
            var previewDlg = new PrintPreviewDialog
            {
                Document = pd,
                Width = 950,
                Height = 750,
                StartPosition = FormStartPosition.CenterScreen,
                Text = $"Xem Trước Khi In ({settings.Paper}) - CodeCipher"
            };

            // Replace built-in print button in PrintPreviewDialog with a custom button that opens Printer Selection Dialog (PrintDialog)
            foreach (Control control in previewDlg.Controls)
            {
                if (control is ToolStrip toolStrip && toolStrip.Items.Count > 0)
                {
                    var oldBtn = toolStrip.Items[0];
                    var printBtn = new ToolStripButton
                    {
                        Image = oldBtn.Image,
                        DisplayStyle = ToolStripItemDisplayStyle.Image,
                        ToolTipText = "In ấn (Chọn máy in)"
                    };

                    printBtn.Click += (s, e) =>
                    {
                        using var printDlg = new PrintDialog
                        {
                            Document = pd,
                            UseEXDialog = true,
                            AllowSomePages = false,
                            AllowSelection = false,
                            AllowCurrentPage = false
                        };

                        if (printDlg.ShowDialog() == DialogResult.OK)
                        {
                            try
                            {
                                pd.Print();
                                previewDlg.Close();
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Không thể thực hiện in: {ex.Message}", "Lỗi In Ấn", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    };

                    toolStrip.Items.RemoveAt(0);
                    toolStrip.Items.Insert(0, printBtn);
                    break;
                }
            }

            previewDlg.ShowDialog();
        }

        public void ShowPrinterSelectionDialog(List<Bitmap> barcodeBitmaps, PrintSettings settings)
        {
            if (barcodeBitmaps.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu mã vạch nào để in.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using var pd = CreatePrintDocument(barcodeBitmaps, settings);
            using var printDlg = new PrintDialog
            {
                Document = pd,
                UseEXDialog = true,
                AllowSomePages = false,
                AllowSelection = false,
                AllowCurrentPage = false
            };

            if (printDlg.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    pd.Print();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Không thể thực hiện lệnh in: {ex.Message}", "Lỗi In Ấn", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private PrintDocument CreatePrintDocument(List<Bitmap> barcodeBitmaps, PrintSettings settings)
        {
            var pd = new PrintDocument
            {
                DocumentName = settings.DocName
            };

            pd.DefaultPageSettings.PaperSize = GetPaperSize(settings.Paper);

            int currentItemIndex = 0;

            // Reset currentItemIndex to 0 every time a print/preview pass begins
            pd.BeginPrint += (sender, e) =>
            {
                currentItemIndex = 0;
            };

            pd.PrintPage += (sender, e) =>
            {
                if (e.Graphics == null) return;

                int pageW = e.PageBounds.Width;
                int pageH = e.PageBounds.Height;

                int cols = Math.Max(1, settings.Columns);
                int rows = Math.Max(1, settings.Rows);

                float marginX = settings.Margin;
                float marginY = settings.Margin;

                float printableW = pageW - (marginX * 2);
                float printableH = pageH - (marginY * 2);

                float cellW = printableW / cols;
                float cellH = printableH / rows;

                for (int row = 0; row < rows; row++)
                {
                    for (int col = 0; col < cols; col++)
                    {
                        if (currentItemIndex >= barcodeBitmaps.Count) break;

                        float cellX = marginX + col * cellW;
                        float cellY = marginY + row * cellH;

                        if (settings.ShowGridLines)
                        {
                            using var pen = new Pen(Color.LightGray, 1) { DashStyle = DashStyle.Dash };
                            e.Graphics.DrawRectangle(pen, cellX, cellY, cellW, cellH);
                        }

                        Bitmap bmp = barcodeBitmaps[currentItemIndex];
                        float innerPadding = 5;
                        float availW = cellW - (innerPadding * 2);
                        float availH = cellH - (innerPadding * 2);

                        float scale = Math.Min(availW / bmp.Width, availH / bmp.Height);
                        float drawW = bmp.Width * scale;
                        float drawH = bmp.Height * scale;

                        float drawX = cellX + (cellW - drawW) / 2f;
                        float drawY = cellY + (cellH - drawH) / 2f;

                        e.Graphics.DrawImage(bmp, drawX, drawY, drawW, drawH);

                        currentItemIndex++;
                    }
                }

                e.HasMorePages = (currentItemIndex < barcodeBitmaps.Count);
            };

            return pd;
        }
    }
}
