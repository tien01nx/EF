using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using CodeCipher.Services;
using ZXing;

namespace CodeCipher
{
    public partial class Form1 : Form
    {
        private readonly BarcodeService _barcodeService;
        private readonly BatchService _batchService;
        private readonly PrintService _printService;
        
        private Color _foreColor = Color.Black;
        private Color _backColor = Color.White;
        private Color _borderColor = Color.Black;
        private Bitmap? _currentBarcodeBitmap;
        private Bitmap? _currentBatchPreviewBitmap;
        private bool _isSyncingControls = false;

        private List<string>? _loadedFileLines = null;

        public Form1()
        {
            InitializeComponent();
            _barcodeService = new BarcodeService();
            _batchService = new BatchService(_barcodeService);
            _printService = new PrintService();

            InitializeEvents();
        }

        private void InitializeEvents()
        {
            this.Load += Form1_Load;

            // Single generator option change triggers
            cmbBarcodeType.SelectedIndexChanged += (s, e) => { SyncSingleToBatch(); GeneratePreview(); UpdateBatchPreview(); };
            txtContent.TextChanged += (s, e) => GeneratePreview();
            numWidth.ValueChanged += (s, e) => { SyncSingleToBatch(); GeneratePreview(); UpdateBatchPreview(); };
            numHeight.ValueChanged += (s, e) => { SyncSingleToBatch(); GeneratePreview(); UpdateBatchPreview(); };
            numMargin.ValueChanged += (s, e) => { SyncSingleToBatch(); GeneratePreview(); UpdateBatchPreview(); };
            cmbTextPosition.SelectedIndexChanged += (s, e) => { SyncSingleToBatch(); GeneratePreview(); UpdateBatchPreview(); };
            chkIncludeBorder.CheckedChanged += (s, e) => { SyncSingleToBatch(); GeneratePreview(); UpdateBatchPreview(); };
            numBorderThickness.ValueChanged += (s, e) => { SyncSingleToBatch(); GeneratePreview(); UpdateBatchPreview(); };
            numBorderPadding.ValueChanged += (s, e) => { SyncSingleToBatch(); GeneratePreview(); UpdateBatchPreview(); };

            btnForeColor.Click += BtnForeColor_Click;
            btnBackColor.Click += BtnBackColor_Click;
            btnBorderColor.Click += BtnBorderColor_Click;

            // Batch style option change triggers
            cmbBatchBarcodeType.SelectedIndexChanged += (s, e) => { SyncBatchToSingle(); GeneratePreview(); UpdateBatchPreview(); };
            numBatchWidth.ValueChanged += (s, e) => { SyncBatchToSingle(); GeneratePreview(); UpdateBatchPreview(); };
            numBatchHeight.ValueChanged += (s, e) => { SyncBatchToSingle(); GeneratePreview(); UpdateBatchPreview(); };
            numBatchMargin.ValueChanged += (s, e) => { SyncBatchToSingle(); GeneratePreview(); UpdateBatchPreview(); };
            cmbBatchTextPosition.SelectedIndexChanged += (s, e) => { SyncBatchToSingle(); GeneratePreview(); UpdateBatchPreview(); };
            chkBatchIncludeBorder.CheckedChanged += (s, e) => { SyncBatchToSingle(); GeneratePreview(); UpdateBatchPreview(); };
            numBatchBorderThickness.ValueChanged += (s, e) => { SyncBatchToSingle(); GeneratePreview(); UpdateBatchPreview(); };
            numBatchBorderPadding.ValueChanged += (s, e) => { SyncBatchToSingle(); GeneratePreview(); UpdateBatchPreview(); };

            btnBatchForeColor.Click += BtnForeColor_Click;
            btnBatchBackColor.Click += BtnBackColor_Click;
            btnBatchBorderColor.Click += BtnBorderColor_Click;

            // Toolbar buttons
            btnCopy.Click += BtnCopy_Click;
            btnSave.Click += BtnSave_Click;
            btnPrint.Click += BtnPrintSingle_Click;

            // Batch sequence generator live triggers
            txtSeqPrefix.TextChanged += (s, e) => UpdateBatchPreview();
            numSeqMin.ValueChanged += (s, e) => UpdateBatchPreview();
            numSeqMax.ValueChanged += (s, e) => UpdateBatchPreview();
            numSeqPadding.ValueChanged += (s, e) => UpdateBatchPreview();
            btnGenSeq.Click += (s, e) => UpdateBatchPreview();

            // Batch & Print tab triggers
            cmbPaperSize.SelectedIndexChanged += (s, e) => UpdateBatchPreview();
            numCols.ValueChanged += (s, e) => UpdateBatchPreview();
            numRows.ValueChanged += (s, e) => UpdateBatchPreview();
            chkPrintGrid.CheckedChanged += (s, e) => UpdateBatchPreview();

            btnBrowseFolder.Click += BtnBrowseFolder_Click;
            btnLoadFile.Click += BtnLoadFile_Click;
            btnClearFile.Click += BtnClearFile_Click;
            btnStartBatch.Click += BtnStartBatch_Click;
            btnPrintBatchPreview.Click += BtnPrintBatchPreview_Click;
        }

        private void Form1_Load(object? sender, EventArgs e)
        {
            _isSyncingControls = true;
            try
            {
                // Populate Barcode Formats for both Single and Batch tabs
                var formats = BarcodeService.SupportedFormats;
                cmbBarcodeType.DataSource = new BindingSource(formats, null);
                cmbBarcodeType.DisplayMember = "Key";
                cmbBarcodeType.ValueMember = "Value";

                cmbBatchBarcodeType.DataSource = new BindingSource(formats, null);
                cmbBatchBarcodeType.DisplayMember = "Key";
                cmbBatchBarcodeType.ValueMember = "Value";

                cmbBarcodeType.SelectedIndex = 0; // Code 39 default
                cmbBatchBarcodeType.SelectedIndex = 0;

                cmbTextPosition.SelectedIndex = 0; // Bottom default
                cmbBatchTextPosition.SelectedIndex = 0;

                cmbPaperSize.SelectedIndex = 0; // A4 default

                UpdateColorPreviews();

                // Default output directory for batch mode
                string defaultPictures = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
                txtBatchFolder.Text = Path.Combine(defaultPictures, "CodeCipherBarcodes");
                cmbBatchExt.SelectedIndex = 0; // PNG
            }
            finally
            {
                _isSyncingControls = false;
            }

            GeneratePreview();
            UpdateBatchPreview();
        }

        private void SyncSingleToBatch()
        {
            if (_isSyncingControls) return;
            _isSyncingControls = true;
            try
            {
                if (cmbBatchBarcodeType.Items.Count > 0 && cmbBarcodeType.SelectedIndex >= 0 && cmbBarcodeType.SelectedIndex < cmbBatchBarcodeType.Items.Count)
                {
                    cmbBatchBarcodeType.SelectedIndex = cmbBarcodeType.SelectedIndex;
                }
                numBatchWidth.Value = numWidth.Value;
                numBatchHeight.Value = numHeight.Value;
                numBatchMargin.Value = numMargin.Value;
                if (cmbBatchTextPosition.Items.Count > 0 && cmbTextPosition.SelectedIndex >= 0 && cmbTextPosition.SelectedIndex < cmbBatchTextPosition.Items.Count)
                {
                    cmbBatchTextPosition.SelectedIndex = cmbTextPosition.SelectedIndex;
                }
                chkBatchIncludeBorder.Checked = chkIncludeBorder.Checked;
                numBatchBorderThickness.Value = numBorderThickness.Value;
                numBatchBorderPadding.Value = numBorderPadding.Value;
            }
            finally
            {
                _isSyncingControls = false;
            }
        }

        private void SyncBatchToSingle()
        {
            if (_isSyncingControls) return;
            _isSyncingControls = true;
            try
            {
                if (cmbBarcodeType.Items.Count > 0 && cmbBatchBarcodeType.SelectedIndex >= 0 && cmbBatchBarcodeType.SelectedIndex < cmbBarcodeType.Items.Count)
                {
                    cmbBarcodeType.SelectedIndex = cmbBatchBarcodeType.SelectedIndex;
                }
                numWidth.Value = numBatchWidth.Value;
                numHeight.Value = numBatchHeight.Value;
                numMargin.Value = numBatchMargin.Value;
                if (cmbTextPosition.Items.Count > 0 && cmbBatchTextPosition.SelectedIndex >= 0 && cmbBatchTextPosition.SelectedIndex < cmbTextPosition.Items.Count)
                {
                    cmbTextPosition.SelectedIndex = cmbBatchTextPosition.SelectedIndex;
                }
                chkIncludeBorder.Checked = chkBatchIncludeBorder.Checked;
                numBorderThickness.Value = numBatchBorderThickness.Value;
                numBorderPadding.Value = numBatchBorderPadding.Value;
            }
            finally
            {
                _isSyncingControls = false;
            }
        }

        private void UpdateColorPreviews()
        {
            pnlForeColorPreview.BackColor = _foreColor;
            pnlBackColorPreview.BackColor = _backColor;
            pnlBorderColorPreview.BackColor = _borderColor;

            pnlBatchForeColorPreview.BackColor = _foreColor;
            pnlBatchBackColorPreview.BackColor = _backColor;
            pnlBatchBorderColorPreview.BackColor = _borderColor;
        }

        private void BtnForeColor_Click(object? sender, EventArgs e)
        {
            colorDialog1.Color = _foreColor;
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                _foreColor = colorDialog1.Color;
                UpdateColorPreviews();
                GeneratePreview();
                UpdateBatchPreview();
            }
        }

        private void BtnBackColor_Click(object? sender, EventArgs e)
        {
            colorDialog1.Color = _backColor;
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                _backColor = colorDialog1.Color;
                UpdateColorPreviews();
                GeneratePreview();
                UpdateBatchPreview();
            }
        }

        private void BtnBorderColor_Click(object? sender, EventArgs e)
        {
            colorDialog1.Color = _borderColor;
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                _borderColor = colorDialog1.Color;
                UpdateColorPreviews();
                GeneratePreview();
                UpdateBatchPreview();
            }
        }

        private LabelPosition GetSelectedTextPosition()
        {
            return cmbTextPosition.SelectedIndex switch
            {
                1 => LabelPosition.Top,
                2 => LabelPosition.None,
                _ => LabelPosition.Bottom
            };
        }

        private BarcodeFormat GetSelectedBarcodeFormat()
        {
            if (cmbBarcodeType.SelectedValue is BarcodeFormat bf)
            {
                return bf;
            }
            if (cmbBarcodeType.SelectedItem is KeyValuePair<string, BarcodeFormat> kvp)
            {
                return kvp.Value;
            }
            return BarcodeFormat.CODE_39;
        }

        private void GeneratePreview()
        {
            if (cmbBarcodeType.SelectedItem == null) return;

            string content = txtContent.Text;
            if (string.IsNullOrWhiteSpace(content))
            {
                picPreview.Image = null;
                lblStatus.Text = "Hãy nhập nội dung dữ liệu mã vạch.";
                lblStatus.ForeColor = Color.DarkOrange;
                return;
            }

            try
            {
                var format = GetSelectedBarcodeFormat();
                var options = new BarcodeOptions
                {
                    Content = content,
                    Format = format,
                    Width = (int)numWidth.Value,
                    Height = (int)numHeight.Value,
                    Margin = (int)numMargin.Value,
                    IncludeLabel = true,
                    TextPosition = GetSelectedTextPosition(),
                    IncludeBorder = chkIncludeBorder.Checked,
                    BorderThickness = (int)numBorderThickness.Value,
                    BorderPadding = (int)numBorderPadding.Value,
                    BorderColor = _borderColor,
                    ForeColor = _foreColor,
                    BackColor = _backColor
                };

                _currentBarcodeBitmap?.Dispose();
                _currentBarcodeBitmap = _barcodeService.GenerateBarcode(options);
                picPreview.Image = _currentBarcodeBitmap;

                lblStatus.Text = $"Đã tạo thành công ({format})";
                lblStatus.ForeColor = Color.ForestGreen;
            }
            catch (Exception ex)
            {
                picPreview.Image = null;
                lblStatus.Text = $"Lỗi: {ex.Message}";
                lblStatus.ForeColor = Color.Red;
            }
        }

        private List<string> GetBatchLines()
        {
            if (_loadedFileLines != null && _loadedFileLines.Count > 0)
            {
                return _loadedFileLines;
            }

            string prefix = txtSeqPrefix.Text;
            int min = (int)numSeqMin.Value;
            int max = (int)numSeqMax.Value;
            int padding = (int)numSeqPadding.Value;

            if (min > max) return new List<string>();

            int count = Math.Min(max - min + 1, 50000);
            var lines = new List<string>(count);
            string formatStr = "D" + padding;
            for (int i = min; i <= max; i++)
            {
                lines.Add($"{prefix}{i.ToString(formatStr)}");
            }
            return lines;
        }

        private void UpdateBatchPreview()
        {
            List<string> lines = GetBatchLines();

            var format = GetSelectedBarcodeFormat();
            var baseOptions = new BarcodeOptions
            {
                Format = format,
                Width = (int)numWidth.Value,
                Height = (int)numHeight.Value,
                Margin = (int)numMargin.Value,
                IncludeLabel = true,
                TextPosition = GetSelectedTextPosition(),
                IncludeBorder = chkIncludeBorder.Checked,
                BorderThickness = (int)numBorderThickness.Value,
                BorderPadding = (int)numBorderPadding.Value,
                BorderColor = _borderColor,
                ForeColor = _foreColor,
                BackColor = _backColor
            };

            PaperType paper = cmbPaperSize.SelectedIndex == 1 ? PaperType.A5 : PaperType.A4;
            int cols = (int)numCols.Value;
            int rows = (int)numRows.Value;
            bool showGrid = chkPrintGrid.Checked;

            int pageW = paper == PaperType.A5 ? 583 : 827;
            int pageH = paper == PaperType.A5 ? 827 : 1169;

            var sheetBmp = new Bitmap(pageW, pageH);
            using (Graphics g = Graphics.FromImage(sheetBmp))
            {
                g.Clear(Color.White);
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

                float margin = 30;
                float printableW = pageW - (margin * 2);
                float printableH = pageH - (margin * 2);

                cols = Math.Max(1, cols);
                rows = Math.Max(1, rows);

                float cellW = printableW / cols;
                float cellH = printableH / rows;

                int itemIdx = 0;

                for (int r = 0; r < rows; r++)
                {
                    for (int c = 0; c < cols; c++)
                    {
                        float cellX = margin + c * cellW;
                        float cellY = margin + r * cellH;

                        if (showGrid)
                        {
                            using var pen = new Pen(Color.LightGray, 1) { DashStyle = System.Drawing.Drawing2D.DashStyle.Dash };
                            g.DrawRectangle(pen, cellX, cellY, cellW, cellH);
                        }

                        if (itemIdx < lines.Count)
                        {
                            string text = lines[itemIdx];
                            var opt = new BarcodeOptions
                            {
                                Content = text,
                                Format = baseOptions.Format,
                                Width = baseOptions.Width,
                                Height = baseOptions.Height,
                                Margin = baseOptions.Margin,
                                IncludeLabel = true,
                                TextPosition = baseOptions.TextPosition,
                                IncludeBorder = baseOptions.IncludeBorder,
                                BorderThickness = baseOptions.BorderThickness,
                                BorderPadding = baseOptions.BorderPadding,
                                BorderColor = baseOptions.BorderColor,
                                ForeColor = baseOptions.ForeColor,
                                BackColor = baseOptions.BackColor,
                                LabelFont = baseOptions.LabelFont
                            };

                            try
                            {
                                using var barcodeBmp = _barcodeService.GenerateBarcode(opt);
                                float innerPadding = 5;
                                float availW = cellW - (innerPadding * 2);
                                float availH = cellH - (innerPadding * 2);

                                float scale = Math.Min(availW / barcodeBmp.Width, availH / barcodeBmp.Height);
                                float drawW = barcodeBmp.Width * scale;
                                float drawH = barcodeBmp.Height * scale;

                                float drawX = cellX + (cellW - drawW) / 2f;
                                float drawY = cellY + (cellH - drawH) / 2f;

                                g.DrawImage(barcodeBmp, drawX, drawY, drawW, drawH);
                            }
                            catch
                            {
                                // Ignore individual item render error in page preview
                            }

                            itemIdx++;
                        }
                    }
                }

                using var pagePen = new Pen(Color.Gray, 1);
                g.DrawRectangle(pagePen, 0, 0, pageW - 1, pageH - 1);
            }

            _currentBatchPreviewBitmap?.Dispose();
            _currentBatchPreviewBitmap = sheetBmp;
            picBatchPreview.Image = _currentBatchPreviewBitmap;
        }

        private void BtnCopy_Click(object? sender, EventArgs e)
        {
            if (_currentBarcodeBitmap == null)
            {
                MessageBox.Show("Chưa có hình ảnh mã vạch để sao chép.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (ExportService.CopyToClipboard(_currentBarcodeBitmap))
            {
                lblStatus.Text = "Đã sao chép hình ảnh vào Clipboard!";
                lblStatus.ForeColor = Color.Blue;
            }
            else
            {
                MessageBox.Show("Không thể sao chép vào Clipboard.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (_currentBarcodeBitmap == null)
            {
                MessageBox.Show("Chưa có hình ảnh mã vạch để lưu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (ExportService.SaveImage(_currentBarcodeBitmap, out string savedPath))
            {
                lblStatus.Text = $"Đã lưu file: {Path.GetFileName(savedPath)}";
                lblStatus.ForeColor = Color.ForestGreen;
            }
        }

        private void BtnPrintSingle_Click(object? sender, EventArgs e)
        {
            if (_currentBarcodeBitmap == null)
            {
                MessageBox.Show("Chưa có hình ảnh mã vạch để in.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var settings = new PrintSettings
            {
                Paper = cmbPaperSize.SelectedIndex == 1 ? PaperType.A5 : PaperType.A4,
                Columns = (int)numCols.Value,
                Rows = (int)numRows.Value,
                ShowGridLines = chkPrintGrid.Checked,
                CopiesPerItem = 1
            };

            _printService.PrintPreviewSingle(_currentBarcodeBitmap, settings);
        }

        private void BtnBrowseFolder_Click(object? sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                txtBatchFolder.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void BtnLoadFile_Click(object? sender, EventArgs e)
        {
            openFileDialog1.Filter = "Text Files (*.txt)|*.txt|CSV Files (*.csv)|*.csv|All Files (*.*)|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string[] fileLines = File.ReadAllLines(openFileDialog1.FileName)
                        .Select(l => l.Trim())
                        .Where(l => !string.IsNullOrEmpty(l))
                        .ToArray();

                    if (fileLines.Length == 0)
                    {
                        MessageBox.Show("Tệp đã chọn không chứa dữ liệu mã vạch.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    _loadedFileLines = new List<string>(fileLines);
                    btnClearFile.Visible = true;
                    lblBatchHelp.Text = $"Đã nạp {fileLines.Length} mã từ tệp {Path.GetFileName(openFileDialog1.FileName)}";
                    lblBatchHelp.ForeColor = Color.ForestGreen;

                    UpdateBatchPreview();
                    MessageBox.Show($"Đã nạp thành công {fileLines.Length} mã từ tệp {Path.GetFileName(openFileDialog1.FileName)}", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Không thể đọc tệp: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnClearFile_Click(object? sender, EventArgs e)
        {
            _loadedFileLines = null;
            btnClearFile.Visible = false;
            lblBatchHelp.Text = "Chế độ tạo/in mã vạch hàng loạt";
            lblBatchHelp.ForeColor = Color.DimGray;
            UpdateBatchPreview();
        }

        private void BtnStartBatch_Click(object? sender, EventArgs e)
        {
            string outDir = txtBatchFolder.Text.Trim();
            if (string.IsNullOrWhiteSpace(outDir))
            {
                MessageBox.Show("Vui lòng chọn thư mục lưu tệp đầu ra.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            List<string> lines = GetBatchLines();
            if (lines.Count == 0)
            {
                MessageBox.Show("Chưa có danh sách mã vạch để xử lý.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var format = GetSelectedBarcodeFormat();
            var baseOptions = new BarcodeOptions
            {
                Format = format,
                Width = (int)numWidth.Value,
                Height = (int)numHeight.Value,
                Margin = (int)numMargin.Value,
                IncludeLabel = true,
                TextPosition = GetSelectedTextPosition(),
                IncludeBorder = chkIncludeBorder.Checked,
                BorderThickness = (int)numBorderThickness.Value,
                BorderPadding = (int)numBorderPadding.Value,
                BorderColor = _borderColor,
                ForeColor = _foreColor,
                BackColor = _backColor
            };

            string ext = cmbBatchExt.SelectedItem?.ToString() ?? "PNG";

            btnStartBatch.Enabled = false;
            Cursor = Cursors.WaitCursor;

            try
            {
                BatchResult result = _batchService.ProcessBatch(lines, baseOptions, outDir, ext);
                MessageBox.Show($"Hoàn tất xuất {result.SuccessCount}/{result.TotalCount} tệp hình ảnh mã vạch thành công tại:\n{outDir}", "Hoàn thành", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Đã xảy ra lỗi khi tạo hàng loạt: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnStartBatch.Enabled = true;
                Cursor = Cursors.Default;
            }
        }

        private void BtnPrintBatchPreview_Click(object? sender, EventArgs e)
        {
            List<string> lines = GetBatchLines();
            if (lines.Count == 0)
            {
                MessageBox.Show("Chưa có danh sách mã vạch để in.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var format = GetSelectedBarcodeFormat();
            var baseOptions = new BarcodeOptions
            {
                Format = format,
                Width = (int)numWidth.Value,
                Height = (int)numHeight.Value,
                Margin = (int)numMargin.Value,
                IncludeLabel = true,
                TextPosition = GetSelectedTextPosition(),
                IncludeBorder = chkIncludeBorder.Checked,
                BorderThickness = (int)numBorderThickness.Value,
                BorderPadding = (int)numBorderPadding.Value,
                BorderColor = _borderColor,
                ForeColor = _foreColor,
                BackColor = _backColor
            };

            btnStartBatch.Enabled = false;
            Cursor = Cursors.WaitCursor;

            try
            {
                var bitmaps = new List<Bitmap>(lines.Count);
                foreach (var line in lines)
                {
                    var opt = new BarcodeOptions
                    {
                        Content = line,
                        Format = baseOptions.Format,
                        Width = baseOptions.Width,
                        Height = baseOptions.Height,
                        Margin = baseOptions.Margin,
                        IncludeLabel = true,
                        TextPosition = baseOptions.TextPosition,
                        IncludeBorder = baseOptions.IncludeBorder,
                        BorderThickness = baseOptions.BorderThickness,
                        BorderPadding = baseOptions.BorderPadding,
                        BorderColor = baseOptions.BorderColor,
                        ForeColor = baseOptions.ForeColor,
                        BackColor = baseOptions.BackColor,
                        LabelFont = baseOptions.LabelFont
                    };

                    bitmaps.Add(_barcodeService.GenerateBarcode(opt));
                }

                var settings = new PrintSettings
                {
                    Paper = cmbPaperSize.SelectedIndex == 1 ? PaperType.A5 : PaperType.A4,
                    Columns = (int)numCols.Value,
                    Rows = (int)numRows.Value,
                    ShowGridLines = chkPrintGrid.Checked,
                    DocName = $"In Mã Vạch Hàng Loạt ({lines.Count} tem) - CodeCipher"
                };

                _printService.ShowPrintPreview(bitmaps, settings);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Đã xảy ra lỗi khi tạo xem trước trang in: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnStartBatch.Enabled = true;
                Cursor = Cursors.Default;
            }
        }
    }
}
