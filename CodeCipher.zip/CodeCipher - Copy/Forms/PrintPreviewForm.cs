using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace CodeCipher.Forms
{
    public class PrintPreviewForm : Form
    {
        private readonly PrintDocument _doc;
        private readonly PrintPreviewControl _previewControl;
        private readonly Label _lblPageInfo;
        private readonly ComboBox _cmbZoom;

        public PrintPreviewForm(PrintDocument doc, string title = "Xem Trước Khi In - CodeCipher")
        {
            _doc = doc;

            Text = title;
            Width = 1050;
            Height = 780;
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            BackColor = Color.FromArgb(241, 245, 249);

            // Top Toolbar Panel
            var pnlTop = new Panel
            {
                Dock = DockStyle.Top,
                Height = 52,
                BackColor = Color.FromArgb(30, 41, 59),
                Padding = new Padding(10)
            };

            var btnPrint = new Button
            {
                Text = "🖨️ Chọn Máy In & In",
                BackColor = Color.FromArgb(16, 185, 129),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold),
                Size = new Size(170, 34),
                Location = new Point(12, 9),
                Cursor = Cursors.Hand
            };
            btnPrint.FlatAppearance.BorderSize = 0;
            btnPrint.Click += BtnPrint_Click;

            var lblZoom = new Label
            {
                Text = "Tỷ lệ xem:",
                ForeColor = Color.FromArgb(226, 232, 240),
                AutoSize = true,
                Location = new Point(200, 16)
            };

            _cmbZoom = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Width = 110,
                Location = new Point(275, 12)
            };
            _cmbZoom.Items.AddRange(new object[] { "50%", "75%", "100%", "150%", "200%", "Vừa trang" });
            _cmbZoom.SelectedIndex = 2; // 100%
            _cmbZoom.SelectedIndexChanged += CmbZoom_SelectedIndexChanged;

            _lblPageInfo = new Label
            {
                Text = "📄 Đang xem trước trang in",
                ForeColor = Color.FromArgb(148, 163, 184),
                AutoSize = true,
                Location = new Point(410, 16)
            };

            var btnClose = new Button
            {
                Text = "❌ Đóng",
                BackColor = Color.FromArgb(239, 68, 68),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold),
                Size = new Size(90, 34),
                Location = new Point(Width - 120, 9),
                Anchor = AnchorStyles.Right | AnchorStyles.Top,
                Cursor = Cursors.Hand
            };
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.Click += (s, e) => Close();

            pnlTop.Controls.Add(btnPrint);
            pnlTop.Controls.Add(lblZoom);
            pnlTop.Controls.Add(_cmbZoom);
            pnlTop.Controls.Add(_lblPageInfo);
            pnlTop.Controls.Add(btnClose);

            // Preview Control
            _previewControl = new PrintPreviewControl
            {
                Document = _doc,
                Dock = DockStyle.Fill,
                Zoom = 1.0,
                AutoZoom = false,
                BackColor = Color.FromArgb(241, 245, 249)
            };

            Controls.Add(_previewControl);
            Controls.Add(pnlTop);
        }

        private void CmbZoom_SelectedIndexChanged(object? sender, EventArgs e)
        {
            switch (_cmbZoom.SelectedIndex)
            {
                case 0: _previewControl.AutoZoom = false; _previewControl.Zoom = 0.5; break;
                case 1: _previewControl.AutoZoom = false; _previewControl.Zoom = 0.75; break;
                case 2: _previewControl.AutoZoom = false; _previewControl.Zoom = 1.0; break;
                case 3: _previewControl.AutoZoom = false; _previewControl.Zoom = 1.5; break;
                case 4: _previewControl.AutoZoom = false; _previewControl.Zoom = 2.0; break;
                case 5: _previewControl.AutoZoom = true; break;
            }
        }

        private void BtnPrint_Click(object? sender, EventArgs e)
        {
            using var printDlg = new PrintDialog
            {
                Document = _doc,
                UseEXDialog = true
            };

            if (printDlg.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    _doc.Print();
                    MessageBox.Show("Đã gửi lệnh in đến máy in thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi khi phát lệnh in: {ex.Message}", "Lỗi In Ấn", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
