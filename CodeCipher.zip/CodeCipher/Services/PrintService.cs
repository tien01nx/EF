using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace CodeCipher.Services
{
    public enum PaperType
    {
        A4,
        A5
    }

    public class PrintSettings
    {
        public PaperType Paper { get; set; } = PaperType.A4;
        public int Columns { get; set; } = 4;
        public int Rows { get; set; } = 8;
        public int Margin { get; set; } = 30; // 30 hundredths of an inch (~7.6mm)
        public bool ShowGridLines { get; set; } = true;
        public int CopiesPerItem { get; set; } = 1;
    }

    public class PrintService
    {
        public static PaperSize GetPaperSize(PaperType type)
        {
            return type switch
            {
                PaperType.A5 => new PaperSize("A5", 583, 827),
                _ => new PaperSize("A4", 827, 1169)
            };
        }

        public void PrintPreviewSingle(Bitmap barcodeBitmap, PrintSettings settings)
        {
            var list = new List<Bitmap>();
            int count = Math.Max(1, settings.CopiesPerItem);
            for (int i = 0; i < count; i++)
            {
                list.Add(barcodeBitmap);
            }

            PrintPreviewBatch(list, settings, "In Xem Trước 1 Mã Vạch - CodeCipher");
        }

        public void PrintPreviewBatch(List<Bitmap> barcodeBitmaps, PrintSettings settings, string docName = "In Mã Vạch Hàng Loạt - CodeCipher")
        {
            if (barcodeBitmaps.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu mã vạch nào để in.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using var pd = new PrintDocument();
            pd.DocumentName = docName;
            pd.DefaultPageSettings.PaperSize = GetPaperSize(settings.Paper);

            int currentItemIndex = 0;

            pd.PrintPage += (sender, e) =>
            {
                if (e.Graphics == null) return;

                int pageW = e.PageBounds.Width;
                int pageH = e.PageBounds.Height;

                int cols = Math.Max(1, settings.Columns);
                int rows = Math.Max(1, settings.Rows);

                float marginX = settings.Margin;
                float marginY = settings.Margin;

                float printableW = pageW - (marginX * 2);
                float printableH = pageH - (marginY * 2);

                float cellW = printableW / cols;
                float cellH = printableH / rows;

                for (int row = 0; row < rows; row++)
                {
                    for (int col = 0; col < cols; col++)
                    {
                        if (currentItemIndex >= barcodeBitmaps.Count)
                        {
                            e.HasMorePages = false;
                            return;
                        }

                        Bitmap bmp = barcodeBitmaps[currentItemIndex];

                        float cellX = marginX + col * cellW;
                        float cellY = marginY + row * cellH;

                        // Calculate aspect ratio fit within cell with padding
                        float innerPadding = 6;
                        float availW = cellW - (innerPadding * 2);
                        float availH = cellH - (innerPadding * 2);

                        float scale = Math.Min(availW / bmp.Width, availH / bmp.Height);
                        float drawW = bmp.Width * scale;
                        float drawH = bmp.Height * scale;

                        float drawX = cellX + (cellW - drawW) / 2f;
                        float drawY = cellY + (cellH - drawH) / 2f;

                        // Optional light grid border for cutting labels
                        if (settings.ShowGridLines)
                        {
                            using var pen = new Pen(Color.LightGray, 1) { DashStyle = DashStyle.Dash };
                            e.Graphics.DrawRectangle(pen, cellX, cellY, cellW, cellH);
                        }

                        e.Graphics.DrawImage(bmp, drawX, drawY, drawW, drawH);

                        currentItemIndex++;
                    }
                }

                e.HasMorePages = currentItemIndex < barcodeBitmaps.Count;
            };

            using var previewDlg = new PrintPreviewDialog
            {
                Document = pd,
                Width = 950,
                Height = 750,
                StartPosition = FormStartPosition.CenterScreen,
                Text = $"Xem Trước Khi In ({settings.Paper}) - CodeCipher"
            };

            previewDlg.ShowDialog();
        }
    }
}
