using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using CodeCipher.Services;
using ZXing;

namespace CodeCipher
{
    public partial class Form1 : Form
    {
        private readonly BarcodeService _barcodeService;
        private readonly BatchService _batchService;
        private readonly PrintService _printService;
        
        private Color _foreColor = Color.Black;
        private Color _backColor = Color.White;
        private Color _borderColor = Color.Black;
        private Bitmap? _currentBarcodeBitmap;

        public Form1()
        {
            InitializeComponent();
            _barcodeService = new BarcodeService();
            _batchService = new BatchService(_barcodeService);
            _printService = new PrintService();

            InitializeEvents();
        }

        private void InitializeEvents()
        {
            this.Load += Form1_Load;

            // Single generator option change triggers
            cmbBarcodeType.SelectedIndexChanged += (s, e) => GeneratePreview();
            txtContent.TextChanged += (s, e) => GeneratePreview();
            numWidth.ValueChanged += (s, e) => GeneratePreview();
            numHeight.ValueChanged += (s, e) => GeneratePreview();
            numMargin.ValueChanged += (s, e) => GeneratePreview();
            cmbTextPosition.SelectedIndexChanged += (s, e) => GeneratePreview();
            chkIncludeBorder.CheckedChanged += (s, e) => GeneratePreview();
            numBorderThickness.ValueChanged += (s, e) => GeneratePreview();
            numBorderPadding.ValueChanged += (s, e) => GeneratePreview();

            btnForeColor.Click += BtnForeColor_Click;
            btnBackColor.Click += BtnBackColor_Click;
            btnBorderColor.Click += BtnBorderColor_Click;

            // Toolbar buttons
            btnCopy.Click += BtnCopy_Click;
            btnSave.Click += BtnSave_Click;
            btnPrint.Click += BtnPrintSingle_Click;

            // Batch & Print tab buttons
            btnBrowseFolder.Click += BtnBrowseFolder_Click;
            btnLoadFile.Click += BtnLoadFile_Click;
            btnGenSeq.Click += BtnGenSeq_Click;
            btnStartBatch.Click += BtnStartBatch_Click;
            btnPrintBatchPreview.Click += BtnPrintBatchPreview_Click;
        }

        private void Form1_Load(object? sender, EventArgs e)
        {
            // Populate Barcode Formats
            cmbBarcodeType.DataSource = new BindingSource(BarcodeService.SupportedFormats, null);
            cmbBarcodeType.DisplayMember = "Key";
            cmbBarcodeType.ValueMember = "Value";
            cmbBarcodeType.SelectedIndex = 0; // Code 128 default

            cmbTextPosition.SelectedIndex = 0; // Bottom default
            cmbPaperSize.SelectedIndex = 0; // A4 default

            UpdateColorPreviews();

            // Default output directory for batch mode
            string defaultPictures = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
            txtBatchFolder.Text = Path.Combine(defaultPictures, "CodeCipherBarcodes");
            cmbBatchExt.SelectedIndex = 0; // PNG

            GeneratePreview();
        }

        private void UpdateColorPreviews()
        {
            pnlForeColorPreview.BackColor = _foreColor;
            pnlBackColorPreview.BackColor = _backColor;
            pnlBorderColorPreview.BackColor = _borderColor;
        }

        private void BtnForeColor_Click(object? sender, EventArgs e)
        {
            colorDialog1.Color = _foreColor;
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                _foreColor = colorDialog1.Color;
                UpdateColorPreviews();
                GeneratePreview();
            }
        }

        private void BtnBackColor_Click(object? sender, EventArgs e)
        {
            colorDialog1.Color = _backColor;
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                _backColor = colorDialog1.Color;
                UpdateColorPreviews();
                GeneratePreview();
            }
        }

        private void BtnBorderColor_Click(object? sender, EventArgs e)
        {
            colorDialog1.Color = _borderColor;
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                _borderColor = colorDialog1.Color;
                UpdateColorPreviews();
                GeneratePreview();
            }
        }

        private LabelPosition GetSelectedTextPosition()
        {
            return cmbTextPosition.SelectedIndex switch
            {
                1 => LabelPosition.Top,
                2 => LabelPosition.None,
                _ => LabelPosition.Bottom
            };
        }

        private void GeneratePreview()
        {
            if (cmbBarcodeType.SelectedValue == null) return;

            string content = txtContent.Text;
            if (string.IsNullOrWhiteSpace(content))
            {
                picPreview.Image = null;
                lblStatus.Text = "⚠️ Hãy nhập nội dung dữ liệu mã vạch.";
                lblStatus.ForeColor = Color.DarkOrange;
                return;
            }

            try
            {
                var format = (BarcodeFormat)cmbBarcodeType.SelectedValue;
                var options = new BarcodeOptions
                {
                    Content = content,
                    Format = format,
                    Width = (int)numWidth.Value,
                    Height = (int)numHeight.Value,
                    Margin = (int)numMargin.Value,
                    IncludeLabel = true,
                    TextPosition = GetSelectedTextPosition(),
                    IncludeBorder = chkIncludeBorder.Checked,
                    BorderThickness = (int)numBorderThickness.Value,
                    BorderPadding = (int)numBorderPadding.Value,
                    BorderColor = _borderColor,
                    ForeColor = _foreColor,
                    BackColor = _backColor
                };

                _currentBarcodeBitmap?.Dispose();
                _currentBarcodeBitmap = _barcodeService.GenerateBarcode(options);
                picPreview.Image = _currentBarcodeBitmap;

                lblStatus.Text = $"✅ Đã tạo thành công ({format})";
                lblStatus.ForeColor = Color.ForestGreen;
            }
            catch (Exception ex)
            {
                picPreview.Image = null;
                lblStatus.Text = $"❌ Lỗi: {ex.Message}";
                lblStatus.ForeColor = Color.Red;
            }
        }

        private void BtnCopy_Click(object? sender, EventArgs e)
        {
            if (_currentBarcodeBitmap == null)
            {
                MessageBox.Show("Chưa có hình ảnh mã vạch để sao chép.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (ExportService.CopyToClipboard(_currentBarcodeBitmap))
            {
                lblStatus.Text = "📋 Đã sao chép hình ảnh vào Clipboard!";
                lblStatus.ForeColor = Color.Blue;
            }
            else
            {
                MessageBox.Show("Không thể sao chép vào Clipboard.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (_currentBarcodeBitmap == null)
            {
                MessageBox.Show("Chưa có hình ảnh mã vạch để lưu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (ExportService.SaveImage(_currentBarcodeBitmap, out string savedPath))
            {
                lblStatus.Text = $"💾 Đã lưu file: {Path.GetFileName(savedPath)}";
                lblStatus.ForeColor = Color.ForestGreen;
            }
        }

        private void BtnPrintSingle_Click(object? sender, EventArgs e)
        {
            if (_currentBarcodeBitmap == null)
            {
                MessageBox.Show("Chưa có hình ảnh mã vạch để in.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var settings = new PrintSettings
            {
                Paper = cmbPaperSize.SelectedIndex == 1 ? PaperType.A5 : PaperType.A4,
                Columns = (int)numCols.Value,
                Rows = (int)numRows.Value,
                ShowGridLines = chkPrintGrid.Checked,
                CopiesPerItem = 1
            };

            _printService.PrintPreviewSingle(_currentBarcodeBitmap, settings);
        }

        private void BtnBrowseFolder_Click(object? sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                txtBatchFolder.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void BtnLoadFile_Click(object? sender, EventArgs e)
        {
            openFileDialog1.Filter = "Text Files (*.txt)|*.txt|CSV Files (*.csv)|*.csv|All Files (*.*)|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string[] lines = File.ReadAllLines(openFileDialog1.FileName);
                    txtBatchContent.Text = string.Join(Environment.NewLine, lines);
                    MessageBox.Show($"Đã nạp {lines.Length} dòng từ tệp {Path.GetFileName(openFileDialog1.FileName)}", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Không thể đọc tệp: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnGenSeq_Click(object? sender, EventArgs e)
        {
            string prefix = txtSeqPrefix.Text;
            int min = (int)numSeqMin.Value;
            int max = (int)numSeqMax.Value;
            int padding = (int)numSeqPadding.Value;

            if (min > max)
            {
                MessageBox.Show("Giá trị bắt đầu (Min) phải nhỏ hơn hoặc bằng giá trị kết thúc (Max).", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int count = max - min + 1;
            if (count > 50000)
            {
                MessageBox.Show("Số lượng sinh quá lớn (tối đa 50,000 mã/lần).", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var lines = new List<string>(count);
            string formatStr = "D" + padding;
            for (int i = min; i <= max; i++)
            {
                lines.Add($"{prefix}{i.ToString(formatStr)}");
            }

            txtBatchContent.Text = string.Join(Environment.NewLine, lines);
            MessageBox.Show($"Đã sinh thành công {count} mã số tăng dần từ {min} đến {max} vào danh sách.", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnStartBatch_Click(object? sender, EventArgs e)
        {
            string outDir = txtBatchFolder.Text.Trim();
            if (string.IsNullOrWhiteSpace(outDir))
            {
                MessageBox.Show("Vui lòng chọn thư mục lưu tệp đầu ra.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string[] lines = txtBatchContent.Lines
                .Select(l => l.Trim())
                .Where(l => !string.IsNullOrEmpty(l))
                .ToArray();

            if (lines.Length == 0)
            {
                MessageBox.Show("Chưa có danh sách mã vạch để xử lý.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var format = cmbBarcodeType.SelectedValue != null ? (BarcodeFormat)cmbBarcodeType.SelectedValue : BarcodeFormat.CODE_39;
            var baseOptions = new BarcodeOptions
            {
                Format = format,
                Width = (int)numWidth.Value,
                Height = (int)numHeight.Value,
                Margin = (int)numMargin.Value,
                IncludeLabel = true,
                TextPosition = GetSelectedTextPosition(),
                IncludeBorder = chkIncludeBorder.Checked,
                BorderThickness = (int)numBorderThickness.Value,
                BorderPadding = (int)numBorderPadding.Value,
                BorderColor = _borderColor,
                ForeColor = _foreColor,
                BackColor = _backColor
            };

            string ext = cmbBatchExt.SelectedItem?.ToString() ?? "PNG";

            txtBatchLog.Text = $"=== Bắt đầu tiến trình tạo {lines.Length} mã vạch ({format}) ===" + Environment.NewLine;
            txtBatchLog.Text += $"Thư mục đích: {outDir}" + Environment.NewLine + Environment.NewLine;

            btnStartBatch.Enabled = false;
            Cursor = Cursors.WaitCursor;

            try
            {
                BatchResult result = _batchService.ProcessBatch(lines, baseOptions, outDir, ext);

                txtBatchLog.AppendText($"[KẾT QUẢ TẠO HÀNG LOẠT]" + Environment.NewLine);
                txtBatchLog.AppendText($"• Tổng số mã cần tạo: {result.TotalCount}" + Environment.NewLine);
                txtBatchLog.AppendText($"• Số mã thành công: {result.SuccessCount}" + Environment.NewLine);
                txtBatchLog.AppendText($"• Số mã thất bại: {result.FailureCount}" + Environment.NewLine);

                if (result.Errors.Count > 0)
                {
                    txtBatchLog.AppendText(Environment.NewLine + "[DANH SÁCH LỖI]" + Environment.NewLine);
                    foreach (var err in result.Errors)
                    {
                        txtBatchLog.AppendText($"❌ {err}" + Environment.NewLine);
                    }
                }

                MessageBox.Show($"Hoàn tất tạo {result.SuccessCount}/{result.TotalCount} mã vạch tại: {outDir}", "Hoàn thành", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                txtBatchLog.AppendText($"LỖI NHIỆM VỤ: {ex.Message}" + Environment.NewLine);
                MessageBox.Show($"Đã xảy ra lỗi khi tạo hàng loạt: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnStartBatch.Enabled = true;
                Cursor = Cursors.Default;
            }
        }

        private void BtnPrintBatchPreview_Click(object? sender, EventArgs e)
        {
            string[] lines = txtBatchContent.Lines
                .Select(l => l.Trim())
                .Where(l => !string.IsNullOrEmpty(l))
                .ToArray();

            if (lines.Length == 0)
            {
                MessageBox.Show("Chưa có danh sách mã vạch để in.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var format = cmbBarcodeType.SelectedValue != null ? (BarcodeFormat)cmbBarcodeType.SelectedValue : BarcodeFormat.CODE_39;
            var baseOptions = new BarcodeOptions
            {
                Format = format,
                Width = (int)numWidth.Value,
                Height = (int)numHeight.Value,
                Margin = (int)numMargin.Value,
                IncludeLabel = true,
                TextPosition = GetSelectedTextPosition(),
                IncludeBorder = chkIncludeBorder.Checked,
                BorderThickness = (int)numBorderThickness.Value,
                BorderPadding = (int)numBorderPadding.Value,
                BorderColor = _borderColor,
                ForeColor = _foreColor,
                BackColor = _backColor
            };

            btnStartBatch.Enabled = false;
            Cursor = Cursors.WaitCursor;

            try
            {
                var bitmaps = new List<Bitmap>(lines.Length);
                foreach (var line in lines)
                {
                    var opt = new BarcodeOptions
                    {
                        Content = line,
                        Format = baseOptions.Format,
                        Width = baseOptions.Width,
                        Height = baseOptions.Height,
                        Margin = baseOptions.Margin,
                        IncludeLabel = baseOptions.IncludeLabel,
                        TextPosition = baseOptions.TextPosition,
                        IncludeBorder = baseOptions.IncludeBorder,
                        BorderThickness = baseOptions.BorderThickness,
                        BorderPadding = baseOptions.BorderPadding,
                        BorderColor = baseOptions.BorderColor,
                        ForeColor = baseOptions.ForeColor,
                        BackColor = baseOptions.BackColor,
                        LabelFont = baseOptions.LabelFont
                    };

                    bitmaps.Add(_barcodeService.GenerateBarcode(opt));
                }

                var settings = new PrintSettings
                {
                    Paper = cmbPaperSize.SelectedIndex == 1 ? PaperType.A5 : PaperType.A4,
                    Columns = (int)numCols.Value,
                    Rows = (int)numRows.Value,
                    ShowGridLines = chkPrintGrid.Checked
                };

                _printService.PrintPreviewBatch(bitmaps, settings, $"In Mã Vạch Hàng Loạt ({lines.Length} tem) - CodeCipher");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Đã xảy ra lỗi khi tạo xem trước trang in: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnStartBatch.Enabled = true;
                Cursor = Cursors.Default;
            }
        }
    }
}
