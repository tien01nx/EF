namespace CodeCipher
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblHeaderSubtitle = new System.Windows.Forms.Label();
            this.lblHeaderTitle = new System.Windows.Forms.Label();
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabSingle = new System.Windows.Forms.TabPage();
            this.splitSingle = new System.Windows.Forms.SplitContainer();
            this.grpStyle = new System.Windows.Forms.GroupBox();
            this.numBorderPadding = new System.Windows.Forms.NumericUpDown();
            this.lblBorderPadding = new System.Windows.Forms.Label();
            this.cmbTextPosition = new System.Windows.Forms.ComboBox();
            this.lblTextPosition = new System.Windows.Forms.Label();
            this.pnlBorderColorPreview = new System.Windows.Forms.Panel();
            this.btnBorderColor = new System.Windows.Forms.Button();
            this.numBorderThickness = new System.Windows.Forms.NumericUpDown();
            this.chkIncludeBorder = new System.Windows.Forms.CheckBox();
            this.pnlBackColorPreview = new System.Windows.Forms.Panel();
            this.pnlForeColorPreview = new System.Windows.Forms.Panel();
            this.btnBackColor = new System.Windows.Forms.Button();
            this.btnForeColor = new System.Windows.Forms.Button();
            this.grpSize = new System.Windows.Forms.GroupBox();
            this.numMargin = new System.Windows.Forms.NumericUpDown();
            this.lblMargin = new System.Windows.Forms.Label();
            this.numHeight = new System.Windows.Forms.NumericUpDown();
            this.lblHeight = new System.Windows.Forms.Label();
            this.numWidth = new System.Windows.Forms.NumericUpDown();
            this.lblWidth = new System.Windows.Forms.Label();
            this.grpContent = new System.Windows.Forms.GroupBox();
            this.lblContentHint = new System.Windows.Forms.Label();
            this.txtContent = new System.Windows.Forms.TextBox();
            this.grpType = new System.Windows.Forms.GroupBox();
            this.cmbBarcodeType = new System.Windows.Forms.ComboBox();
            this.pnlPreviewCard = new System.Windows.Forms.Panel();
            this.picPreview = new System.Windows.Forms.PictureBox();
            this.pnlToolbar = new System.Windows.Forms.FlowLayoutPanel();
            this.btnCopy = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.tabBatch = new System.Windows.Forms.TabPage();
            this.grpBatchLog = new System.Windows.Forms.GroupBox();
            this.txtBatchLog = new System.Windows.Forms.TextBox();
            this.grpPrintConfig = new System.Windows.Forms.GroupBox();
            this.btnPrintBatchPreview = new System.Windows.Forms.Button();
            this.chkPrintGrid = new System.Windows.Forms.CheckBox();
            this.numRows = new System.Windows.Forms.NumericUpDown();
            this.lblTimes = new System.Windows.Forms.Label();
            this.numCols = new System.Windows.Forms.NumericUpDown();
            this.lblColsRows = new System.Windows.Forms.Label();
            this.cmbPaperSize = new System.Windows.Forms.ComboBox();
            this.lblPaperSize = new System.Windows.Forms.Label();
            this.grpBatchConfig = new System.Windows.Forms.GroupBox();
            this.btnStartBatch = new System.Windows.Forms.Button();
            this.cmbBatchExt = new System.Windows.Forms.ComboBox();
            this.lblBatchExt = new System.Windows.Forms.Label();
            this.btnBrowseFolder = new System.Windows.Forms.Button();
            this.txtBatchFolder = new System.Windows.Forms.TextBox();
            this.lblBatchFolder = new System.Windows.Forms.Label();
            this.grpBatchInput = new System.Windows.Forms.GroupBox();
            this.txtBatchContent = new System.Windows.Forms.TextBox();
            this.grpSeqGen = new System.Windows.Forms.GroupBox();
            this.btnGenSeq = new System.Windows.Forms.Button();
            this.numSeqPadding = new System.Windows.Forms.NumericUpDown();
            this.lblSeqPadding = new System.Windows.Forms.Label();
            this.numSeqMax = new System.Windows.Forms.NumericUpDown();
            this.lblSeqMax = new System.Windows.Forms.Label();
            this.numSeqMin = new System.Windows.Forms.NumericUpDown();
            this.lblSeqMin = new System.Windows.Forms.Label();
            this.txtSeqPrefix = new System.Windows.Forms.TextBox();
            this.lblSeqPrefix = new System.Windows.Forms.Label();
            this.pnlBatchTopBar = new System.Windows.Forms.Panel();
            this.btnLoadFile = new System.Windows.Forms.Button();
            this.lblBatchHelp = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();

            this.pnlHeader.SuspendLayout();
            this.tabMain.SuspendLayout();
            this.tabSingle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitSingle)).BeginInit();
            this.splitSingle.Panel1.SuspendLayout();
            this.splitSingle.Panel2.SuspendLayout();
            this.splitSingle.SuspendLayout();
            this.grpStyle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numBorderPadding)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBorderThickness)).BeginInit();
            this.grpSize.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numMargin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWidth)).BeginInit();
            this.grpContent.SuspendLayout();
            this.grpType.SuspendLayout();
            this.pnlPreviewCard.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPreview)).BeginInit();
            this.pnlToolbar.SuspendLayout();
            this.tabBatch.SuspendLayout();
            this.grpBatchLog.SuspendLayout();
            this.grpPrintConfig.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRows)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCols)).BeginInit();
            this.grpBatchConfig.SuspendLayout();
            this.grpBatchInput.SuspendLayout();
            this.grpSeqGen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSeqPadding)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSeqMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSeqMin)).BeginInit();
            this.pnlBatchTopBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlHeader
            // 
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.pnlHeader.Controls.Add(this.lblHeaderSubtitle);
            this.pnlHeader.Controls.Add(this.lblHeaderTitle);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(984, 65);
            this.pnlHeader.TabIndex = 0;
            // 
            // lblHeaderSubtitle
            // 
            this.lblHeaderSubtitle.AutoSize = true;
            this.lblHeaderSubtitle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblHeaderSubtitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(163)))), ((int)(((byte)(184)))));
            this.lblHeaderSubtitle.Location = new System.Drawing.Point(20, 36);
            this.lblHeaderSubtitle.Name = "lblHeaderSubtitle";
            this.lblHeaderSubtitle.Size = new System.Drawing.Size(434, 15);
            this.lblHeaderSubtitle.TabIndex = 1;
            this.lblHeaderSubtitle.Text = "Hỗ trợ 1D (Code 128, Code 39, EAN-13...) & 2D (QR Code, Data Matrix...)";
            // 
            // lblHeaderTitle
            // 
            this.lblHeaderTitle.AutoSize = true;
            this.lblHeaderTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblHeaderTitle.ForeColor = System.Drawing.Color.White;
            this.lblHeaderTitle.Location = new System.Drawing.Point(18, 9);
            this.lblHeaderTitle.Name = "lblHeaderTitle";
            this.lblHeaderTitle.Size = new System.Drawing.Size(326, 25);
            this.lblHeaderTitle.TabIndex = 0;
            this.lblHeaderTitle.Text = "⚡ CodeCipher - Barcode Studio";
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabSingle);
            this.tabMain.Controls.Add(this.tabBatch);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tabMain.Location = new System.Drawing.Point(0, 65);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(984, 596);
            this.tabMain.TabIndex = 1;
            // 
            // tabSingle
            // 
            this.tabSingle.Controls.Add(this.splitSingle);
            this.tabSingle.Location = new System.Drawing.Point(4, 26);
            this.tabSingle.Name = "tabSingle";
            this.tabSingle.Padding = new System.Windows.Forms.Padding(8);
            this.tabSingle.Size = new System.Drawing.Size(976, 566);
            this.tabSingle.TabIndex = 0;
            this.tabSingle.Text = " 🏷️ Sinh mã đơn ";
            this.tabSingle.UseVisualStyleBackColor = true;
            // 
            // splitSingle
            // 
            this.splitSingle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitSingle.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitSingle.Location = new System.Drawing.Point(8, 8);
            this.splitSingle.Name = "splitSingle";
            // 
            // splitSingle.Panel1
            // 
            this.splitSingle.Panel1.AutoScroll = true;
            this.splitSingle.Panel1.Controls.Add(this.grpStyle);
            this.splitSingle.Panel1.Controls.Add(this.grpSize);
            this.splitSingle.Panel1.Controls.Add(this.grpContent);
            this.splitSingle.Panel1.Controls.Add(this.grpType);
            // 
            // splitSingle.Panel2
            // 
            this.splitSingle.Panel2.Controls.Add(this.pnlPreviewCard);
            this.splitSingle.Panel2.Controls.Add(this.pnlToolbar);
            this.splitSingle.Size = new System.Drawing.Size(960, 550);
            this.splitSingle.SplitterDistance = 370;
            this.splitSingle.TabIndex = 0;
            // 
            // grpStyle
            // 
            this.grpStyle.Controls.Add(this.numBorderPadding);
            this.grpStyle.Controls.Add(this.lblBorderPadding);
            this.grpStyle.Controls.Add(this.cmbTextPosition);
            this.grpStyle.Controls.Add(this.lblTextPosition);
            this.grpStyle.Controls.Add(this.pnlBorderColorPreview);
            this.grpStyle.Controls.Add(this.btnBorderColor);
            this.grpStyle.Controls.Add(this.numBorderThickness);
            this.grpStyle.Controls.Add(this.chkIncludeBorder);
            this.grpStyle.Controls.Add(this.pnlBackColorPreview);
            this.grpStyle.Controls.Add(this.pnlForeColorPreview);
            this.grpStyle.Controls.Add(this.btnBackColor);
            this.grpStyle.Controls.Add(this.btnForeColor);
            this.grpStyle.Dock = System.Windows.Forms.DockStyle.Top;
            this.grpStyle.Location = new System.Drawing.Point(0, 345);
            this.grpStyle.Name = "grpStyle";
            this.grpStyle.Size = new System.Drawing.Size(370, 215);
            this.grpStyle.TabIndex = 3;
            this.grpStyle.TabStop = false;
            this.grpStyle.Text = "🎨 Màu sắc, Vị trí chữ & Khung viền";
            // 
            // numBorderPadding
            // 
            this.numBorderPadding.Location = new System.Drawing.Point(170, 175);
            this.numBorderPadding.Maximum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numBorderPadding.Name = "numBorderPadding";
            this.numBorderPadding.Size = new System.Drawing.Size(55, 25);
            this.numBorderPadding.TabIndex = 10;
            this.numBorderPadding.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // lblBorderPadding
            // 
            this.lblBorderPadding.AutoSize = true;
            this.lblBorderPadding.Location = new System.Drawing.Point(15, 177);
            this.lblBorderPadding.Name = "lblBorderPadding";
            this.lblBorderPadding.Size = new System.Drawing.Size(149, 17);
            this.lblBorderPadding.TabIndex = 9;
            this.lblBorderPadding.Text = "Lề viền (Border Padding):";
            // 
            // cmbTextPosition
            // 
            this.cmbTextPosition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTextPosition.FormattingEnabled = true;
            this.cmbTextPosition.Items.AddRange(new object[] {
            "Bên dưới mã (Bottom)",
            "Bên trên mã (Top)",
            "Không hiển thị (None)"});
            this.cmbTextPosition.Location = new System.Drawing.Point(145, 100);
            this.cmbTextPosition.Name = "cmbTextPosition";
            this.cmbTextPosition.Size = new System.Drawing.Size(204, 25);
            this.cmbTextPosition.TabIndex = 4;
            // 
            // lblTextPosition
            // 
            this.lblTextPosition.AutoSize = true;
            this.lblTextPosition.Location = new System.Drawing.Point(15, 103);
            this.lblTextPosition.Name = "lblTextPosition";
            this.lblTextPosition.Size = new System.Drawing.Size(107, 17);
            this.lblTextPosition.TabIndex = 3;
            this.lblTextPosition.Text = "Vị trí văn bản chữ:";
            // 
            // pnlBorderColorPreview
            // 
            this.pnlBorderColorPreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBorderColorPreview.Location = new System.Drawing.Point(325, 137);
            this.pnlBorderColorPreview.Name = "pnlBorderColorPreview";
            this.pnlBorderColorPreview.Size = new System.Drawing.Size(24, 24);
            this.pnlBorderColorPreview.TabIndex = 8;
            // 
            // btnBorderColor
            // 
            this.btnBorderColor.Location = new System.Drawing.Point(235, 134);
            this.btnBorderColor.Name = "btnBorderColor";
            this.btnBorderColor.Size = new System.Drawing.Size(84, 30);
            this.btnBorderColor.TabIndex = 7;
            this.btnBorderColor.Text = "Màu Viền";
            this.btnBorderColor.UseVisualStyleBackColor = true;
            // 
            // numBorderThickness
            // 
            this.numBorderThickness.Location = new System.Drawing.Point(170, 137);
            this.numBorderThickness.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numBorderThickness.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numBorderThickness.Name = "numBorderThickness";
            this.numBorderThickness.Size = new System.Drawing.Size(55, 25);
            this.numBorderThickness.TabIndex = 6;
            this.numBorderThickness.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // chkIncludeBorder
            // 
            this.chkIncludeBorder.AutoSize = true;
            this.chkIncludeBorder.Checked = true;
            this.chkIncludeBorder.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkIncludeBorder.Location = new System.Drawing.Point(15, 138);
            this.chkIncludeBorder.Name = "chkIncludeBorder";
            this.chkIncludeBorder.Size = new System.Drawing.Size(149, 21);
            this.chkIncludeBorder.TabIndex = 5;
            this.chkIncludeBorder.Text = "Vẽ khung viền (Border)";
            this.chkIncludeBorder.UseVisualStyleBackColor = true;
            // 
            // pnlBackColorPreview
            // 
            this.pnlBackColorPreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBackColorPreview.Location = new System.Drawing.Point(145, 65);
            this.pnlBackColorPreview.Name = "pnlBackColorPreview";
            this.pnlBackColorPreview.Size = new System.Drawing.Size(24, 24);
            this.pnlBackColorPreview.TabIndex = 2;
            // 
            // pnlForeColorPreview
            // 
            this.pnlForeColorPreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlForeColorPreview.Location = new System.Drawing.Point(145, 27);
            this.pnlForeColorPreview.Name = "pnlForeColorPreview";
            this.pnlForeColorPreview.Size = new System.Drawing.Size(24, 24);
            this.pnlForeColorPreview.TabIndex = 1;
            // 
            // btnBackColor
            // 
            this.btnBackColor.Location = new System.Drawing.Point(15, 62);
            this.btnBackColor.Name = "btnBackColor";
            this.btnBackColor.Size = new System.Drawing.Size(120, 30);
            this.btnBackColor.TabIndex = 2;
            this.btnBackColor.Text = "Màu Nền";
            this.btnBackColor.UseVisualStyleBackColor = true;
            // 
            // btnForeColor
            // 
            this.btnForeColor.Location = new System.Drawing.Point(15, 24);
            this.btnForeColor.Name = "btnForeColor";
            this.btnForeColor.Size = new System.Drawing.Size(120, 30);
            this.btnForeColor.TabIndex = 0;
            this.btnForeColor.Text = "Màu Vạch";
            this.btnForeColor.UseVisualStyleBackColor = true;
            // 
            // grpSize
            // 
            this.grpSize.Controls.Add(this.numMargin);
            this.grpSize.Controls.Add(this.lblMargin);
            this.grpSize.Controls.Add(this.numHeight);
            this.grpSize.Controls.Add(this.lblHeight);
            this.grpSize.Controls.Add(this.numWidth);
            this.grpSize.Controls.Add(this.lblWidth);
            this.grpSize.Dock = System.Windows.Forms.DockStyle.Top;
            this.grpSize.Location = new System.Drawing.Point(0, 220);
            this.grpSize.Name = "grpSize";
            this.grpSize.Size = new System.Drawing.Size(370, 125);
            this.grpSize.TabIndex = 2;
            this.grpSize.TabStop = false;
            this.grpSize.Text = "📐 Kích thước (Pixels)";
            // 
            // numMargin
            // 
            this.numMargin.Location = new System.Drawing.Point(100, 88);
            this.numMargin.Name = "numMargin";
            this.numMargin.Size = new System.Drawing.Size(120, 25);
            this.numMargin.TabIndex = 5;
            this.numMargin.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // lblMargin
            // 
            this.lblMargin.AutoSize = true;
            this.lblMargin.Location = new System.Drawing.Point(15, 90);
            this.lblMargin.Name = "lblMargin";
            this.lblMargin.Size = new System.Drawing.Size(73, 17);
            this.lblMargin.TabIndex = 4;
            this.lblMargin.Text = "Lề (Margin):";
            // 
            // numHeight
            // 
            this.numHeight.Location = new System.Drawing.Point(100, 56);
            this.numHeight.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.numHeight.Minimum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numHeight.Name = "numHeight";
            this.numHeight.Size = new System.Drawing.Size(120, 25);
            this.numHeight.TabIndex = 3;
            this.numHeight.Value = new decimal(new int[] {
            150,
            0,
            0,
            0});
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Location = new System.Drawing.Point(15, 58);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(68, 17);
            this.lblHeight.TabIndex = 2;
            this.lblHeight.Text = "Chiều cao:";
            // 
            // numWidth
            // 
            this.numWidth.Location = new System.Drawing.Point(100, 24);
            this.numWidth.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.numWidth.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numWidth.Name = "numWidth";
            this.numWidth.Size = new System.Drawing.Size(120, 25);
            this.numWidth.TabIndex = 1;
            this.numWidth.Value = new decimal(new int[] {
            350,
            0,
            0,
            0});
            // 
            // lblWidth
            // 
            this.lblWidth.AutoSize = true;
            this.lblWidth.Location = new System.Drawing.Point(15, 26);
            this.lblWidth.Name = "lblWidth";
            this.lblWidth.Size = new System.Drawing.Size(62, 17);
            this.lblWidth.TabIndex = 0;
            this.lblWidth.Text = "Độ rộng:";
            // 
            // grpContent
            // 
            this.grpContent.Controls.Add(this.lblContentHint);
            this.grpContent.Controls.Add(this.txtContent);
            this.grpContent.Dock = System.Windows.Forms.DockStyle.Top;
            this.grpContent.Location = new System.Drawing.Point(0, 75);
            this.grpContent.Name = "grpContent";
            this.grpContent.Size = new System.Drawing.Size(370, 145);
            this.grpContent.TabIndex = 1;
            this.grpContent.TabStop = false;
            this.grpContent.Text = "✏️ Nội dung mã";
            // 
            // lblContentHint
            // 
            this.lblContentHint.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblContentHint.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lblContentHint.ForeColor = System.Drawing.Color.Gray;
            this.lblContentHint.Location = new System.Drawing.Point(3, 102);
            this.lblContentHint.Name = "lblContentHint";
            this.lblContentHint.Size = new System.Drawing.Size(364, 40);
            this.lblContentHint.TabIndex = 1;
            this.lblContentHint.Text = "Nhập chữ, số hoặc liên kết URL tùy chọn.";
            // 
            // txtContent
            // 
            this.txtContent.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtContent.Location = new System.Drawing.Point(3, 21);
            this.txtContent.Multiline = true;
            this.txtContent.Name = "txtContent";
            this.txtContent.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtContent.Size = new System.Drawing.Size(364, 75);
            this.txtContent.TabIndex = 0;
            this.txtContent.Text = "CODECIPHER-2026";
            // 
            // grpType
            // 
            this.grpType.Controls.Add(this.cmbBarcodeType);
            this.grpType.Dock = System.Windows.Forms.DockStyle.Top;
            this.grpType.Location = new System.Drawing.Point(0, 0);
            this.grpType.Name = "grpType";
            this.grpType.Size = new System.Drawing.Size(370, 75);
            this.grpType.TabIndex = 0;
            this.grpType.TabStop = false;
            this.grpType.Text = "📌 Định dạng Mã (Format)";
            // 
            // cmbBarcodeType
            // 
            this.cmbBarcodeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBarcodeType.FormattingEnabled = true;
            this.cmbBarcodeType.Location = new System.Drawing.Point(15, 30);
            this.cmbBarcodeType.Name = "cmbBarcodeType";
            this.cmbBarcodeType.Size = new System.Drawing.Size(335, 25);
            this.cmbBarcodeType.TabIndex = 0;
            // 
            // pnlPreviewCard
            // 
            this.pnlPreviewCard.AutoScroll = true;
            this.pnlPreviewCard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(250)))), ((int)(((byte)(252)))));
            this.pnlPreviewCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPreviewCard.Controls.Add(this.picPreview);
            this.pnlPreviewCard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPreviewCard.Location = new System.Drawing.Point(0, 0);
            this.pnlPreviewCard.Name = "pnlPreviewCard";
            this.pnlPreviewCard.Padding = new System.Windows.Forms.Padding(20);
            this.pnlPreviewCard.Size = new System.Drawing.Size(586, 490);
            this.pnlPreviewCard.TabIndex = 0;
            // 
            // picPreview
            // 
            this.picPreview.BackColor = System.Drawing.Color.White;
            this.picPreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picPreview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picPreview.Location = new System.Drawing.Point(20, 20);
            this.picPreview.Name = "picPreview";
            this.picPreview.Size = new System.Drawing.Size(544, 448);
            this.picPreview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picPreview.TabIndex = 0;
            this.picPreview.TabStop = false;
            // 
            // pnlToolbar
            // 
            this.pnlToolbar.Controls.Add(this.btnCopy);
            this.pnlToolbar.Controls.Add(this.btnSave);
            this.pnlToolbar.Controls.Add(this.btnPrint);
            this.pnlToolbar.Controls.Add(this.lblStatus);
            this.pnlToolbar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlToolbar.Location = new System.Drawing.Point(0, 490);
            this.pnlToolbar.Name = "pnlToolbar";
            this.pnlToolbar.Padding = new System.Windows.Forms.Padding(10, 10, 10, 10);
            this.pnlToolbar.Size = new System.Drawing.Size(586, 60);
            this.pnlToolbar.TabIndex = 1;
            // 
            // btnCopy
            // 
            this.btnCopy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(245)))), ((int)(((byte)(249)))));
            this.btnCopy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCopy.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCopy.Location = new System.Drawing.Point(13, 13);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(120, 36);
            this.btnCopy.TabIndex = 0;
            this.btnCopy.Text = "📋 Sao Chép";
            this.btnCopy.UseVisualStyleBackColor = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(99)))), ((int)(((byte)(235)))));
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(139, 13);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(130, 36);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "💾 Lưu File Ảnh";
            this.btnSave.UseVisualStyleBackColor = false;
            // 
            // btnPrint
            // 
            this.btnPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(245)))), ((int)(((byte)(249)))));
            this.btnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrint.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnPrint.Location = new System.Drawing.Point(275, 13);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(150, 36);
            this.btnPrint.TabIndex = 2;
            this.btnPrint.Text = "🖨️ In Xem Trước (A4/A5)";
            this.btnPrint.UseVisualStyleBackColor = false;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lblStatus.ForeColor = System.Drawing.Color.ForestGreen;
            this.lblStatus.Location = new System.Drawing.Point(431, 23);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(130, 15);
            this.lblStatus.TabIndex = 3;
            this.lblStatus.Text = "Đã cập nhật xem trước.";
            // 
            // tabBatch
            // 
            this.tabBatch.Controls.Add(this.grpBatchLog);
            this.tabBatch.Controls.Add(this.grpPrintConfig);
            this.tabBatch.Controls.Add(this.grpBatchConfig);
            this.tabBatch.Controls.Add(this.grpBatchInput);
            this.tabBatch.Controls.Add(this.pnlBatchTopBar);
            this.tabBatch.Location = new System.Drawing.Point(4, 26);
            this.tabBatch.Name = "tabBatch";
            this.tabBatch.Padding = new System.Windows.Forms.Padding(10);
            this.tabBatch.Size = new System.Drawing.Size(976, 566);
            this.tabBatch.TabIndex = 1;
            this.tabBatch.Text = " 📦 Tạo hàng loạt (Batch) ";
            this.tabBatch.UseVisualStyleBackColor = true;
            // 
            // grpBatchLog
            // 
            this.grpBatchLog.Controls.Add(this.txtBatchLog);
            this.grpBatchLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grpBatchLog.Location = new System.Drawing.Point(480, 275);
            this.grpBatchLog.Name = "grpBatchLog";
            this.grpBatchLog.Size = new System.Drawing.Size(486, 281);
            this.grpBatchLog.TabIndex = 4;
            this.grpBatchLog.TabStop = false;
            this.grpBatchLog.Text = "📋 Nhật ký thực hiện";
            // 
            // txtBatchLog
            // 
            this.txtBatchLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBatchLog.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBatchLog.Location = new System.Drawing.Point(3, 21);
            this.txtBatchLog.Multiline = true;
            this.txtBatchLog.Name = "txtBatchLog";
            this.txtBatchLog.ReadOnly = true;
            this.txtBatchLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtBatchLog.Size = new System.Drawing.Size(480, 257);
            this.txtBatchLog.TabIndex = 0;
            // 
            // grpPrintConfig
            // 
            this.grpPrintConfig.Controls.Add(this.btnPrintBatchPreview);
            this.grpPrintConfig.Controls.Add(this.chkPrintGrid);
            this.grpPrintConfig.Controls.Add(this.numRows);
            this.grpPrintConfig.Controls.Add(this.lblTimes);
            this.grpPrintConfig.Controls.Add(this.numCols);
            this.grpPrintConfig.Controls.Add(this.lblColsRows);
            this.grpPrintConfig.Controls.Add(this.cmbPaperSize);
            this.grpPrintConfig.Controls.Add(this.lblPaperSize);
            this.grpPrintConfig.Dock = System.Windows.Forms.DockStyle.Top;
            this.grpPrintConfig.Location = new System.Drawing.Point(480, 165);
            this.grpPrintConfig.Name = "grpPrintConfig";
            this.grpPrintConfig.Size = new System.Drawing.Size(486, 110);
            this.grpPrintConfig.TabIndex = 3;
            this.grpPrintConfig.TabStop = false;
            this.grpPrintConfig.Text = "🖨️ Bố cục in trang (A4 / A5)";
            // 
            // btnPrintBatchPreview
            // 
            this.btnPrintBatchPreview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(70)))), ((int)(((byte)(229)))));
            this.btnPrintBatchPreview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrintBatchPreview.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnPrintBatchPreview.ForeColor = System.Drawing.Color.White;
            this.btnPrintBatchPreview.Location = new System.Drawing.Point(260, 60);
            this.btnPrintBatchPreview.Name = "btnPrintBatchPreview";
            this.btnPrintBatchPreview.Size = new System.Drawing.Size(210, 36);
            this.btnPrintBatchPreview.TabIndex = 7;
            this.btnPrintBatchPreview.Text = "🖨️ In Xem Trước Hàng Loạt";
            this.btnPrintBatchPreview.UseVisualStyleBackColor = false;
            // 
            // chkPrintGrid
            // 
            this.chkPrintGrid.AutoSize = true;
            this.chkPrintGrid.Checked = true;
            this.chkPrintGrid.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkPrintGrid.Location = new System.Drawing.Point(15, 68);
            this.chkPrintGrid.Name = "chkPrintGrid";
            this.chkPrintGrid.Size = new System.Drawing.Size(222, 21);
            this.chkPrintGrid.TabIndex = 6;
            this.chkPrintGrid.Text = "Vẽ đường nét đứt chia tem nhãn";
            this.chkPrintGrid.UseVisualStyleBackColor = true;
            // 
            // numRows
            // 
            this.numRows.Location = new System.Drawing.Point(400, 25);
            this.numRows.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numRows.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numRows.Name = "numRows";
            this.numRows.Size = new System.Drawing.Size(55, 25);
            this.numRows.TabIndex = 5;
            this.numRows.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // lblTimes
            // 
            this.lblTimes.AutoSize = true;
            this.lblTimes.Location = new System.Drawing.Point(380, 28);
            this.lblTimes.Name = "lblTimes";
            this.lblTimes.Size = new System.Drawing.Size(14, 17);
            this.lblTimes.TabIndex = 4;
            this.lblTimes.Text = "x";
            // 
            // numCols
            // 
            this.numCols.Location = new System.Drawing.Point(320, 25);
            this.numCols.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.numCols.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numCols.Name = "numCols";
            this.numCols.Size = new System.Drawing.Size(55, 25);
            this.numCols.TabIndex = 3;
            this.numCols.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // lblColsRows
            // 
            this.lblColsRows.AutoSize = true;
            this.lblColsRows.Location = new System.Drawing.Point(235, 28);
            this.lblColsRows.Name = "lblColsRows";
            this.lblColsRows.Size = new System.Drawing.Size(81, 17);
            this.lblColsRows.TabIndex = 2;
            this.lblColsRows.Text = "Cột x Hàng:";
            // 
            // cmbPaperSize
            // 
            this.cmbPaperSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPaperSize.FormattingEnabled = true;
            this.cmbPaperSize.Items.AddRange(new object[] {
            "Giấy A4",
            "Giấy A5"});
            this.cmbPaperSize.Location = new System.Drawing.Point(90, 25);
            this.cmbPaperSize.Name = "cmbPaperSize";
            this.cmbPaperSize.Size = new System.Drawing.Size(120, 25);
            this.cmbPaperSize.TabIndex = 1;
            // 
            // lblPaperSize
            // 
            this.lblPaperSize.AutoSize = true;
            this.lblPaperSize.Location = new System.Drawing.Point(15, 28);
            this.lblPaperSize.Name = "lblPaperSize";
            this.lblPaperSize.Size = new System.Drawing.Size(65, 17);
            this.lblPaperSize.TabIndex = 0;
            this.lblPaperSize.Text = "Khổ giấy:";
            // 
            // grpBatchConfig
            // 
            this.grpBatchConfig.Controls.Add(this.btnStartBatch);
            this.grpBatchConfig.Controls.Add(this.cmbBatchExt);
            this.grpBatchConfig.Controls.Add(this.lblBatchExt);
            this.grpBatchConfig.Controls.Add(this.btnBrowseFolder);
            this.grpBatchConfig.Controls.Add(this.txtBatchFolder);
            this.grpBatchConfig.Controls.Add(this.lblBatchFolder);
            this.grpBatchConfig.Dock = System.Windows.Forms.DockStyle.Top;
            this.grpBatchConfig.Location = new System.Drawing.Point(480, 55);
            this.grpBatchConfig.Name = "grpBatchConfig";
            this.grpBatchConfig.Size = new System.Drawing.Size(486, 110);
            this.grpBatchConfig.TabIndex = 2;
            this.grpBatchConfig.TabStop = false;
            this.grpBatchConfig.Text = "⚙️ Đích đến & Định dạng xuất tệp";
            // 
            // btnStartBatch
            // 
            this.btnStartBatch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(185)))), ((int)(((byte)(129)))));
            this.btnStartBatch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStartBatch.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnStartBatch.ForeColor = System.Drawing.Color.White;
            this.btnStartBatch.Location = new System.Drawing.Point(260, 65);
            this.btnStartBatch.Name = "btnStartBatch";
            this.btnStartBatch.Size = new System.Drawing.Size(210, 36);
            this.btnStartBatch.TabIndex = 5;
            this.btnStartBatch.Text = "⚡ Xuất File Ảnh Hàng Loạt";
            this.btnStartBatch.UseVisualStyleBackColor = false;
            // 
            // cmbBatchExt
            // 
            this.cmbBatchExt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBatchExt.FormattingEnabled = true;
            this.cmbBatchExt.Items.AddRange(new object[] {
            "PNG",
            "JPG",
            "BMP",
            "GIF"});
            this.cmbBatchExt.Location = new System.Drawing.Point(120, 70);
            this.cmbBatchExt.Name = "cmbBatchExt";
            this.cmbBatchExt.Size = new System.Drawing.Size(120, 25);
            this.cmbBatchExt.TabIndex = 4;
            // 
            // lblBatchExt
            // 
            this.lblBatchExt.AutoSize = true;
            this.lblBatchExt.Location = new System.Drawing.Point(15, 73);
            this.lblBatchExt.Name = "lblBatchExt";
            this.lblBatchExt.Size = new System.Drawing.Size(95, 17);
            this.lblBatchExt.TabIndex = 3;
            this.lblBatchExt.Text = "Định dạng file:";
            // 
            // btnBrowseFolder
            // 
            this.btnBrowseFolder.Location = new System.Drawing.Point(420, 25);
            this.btnBrowseFolder.Name = "btnBrowseFolder";
            this.btnBrowseFolder.Size = new System.Drawing.Size(40, 30);
            this.btnBrowseFolder.TabIndex = 2;
            this.btnBrowseFolder.Text = "...";
            this.btnBrowseFolder.UseVisualStyleBackColor = true;
            // 
            // txtBatchFolder
            // 
            this.txtBatchFolder.Location = new System.Drawing.Point(120, 27);
            this.txtBatchFolder.Name = "txtBatchFolder";
            this.txtBatchFolder.Size = new System.Drawing.Size(294, 25);
            this.txtBatchFolder.TabIndex = 1;
            // 
            // lblBatchFolder
            // 
            this.lblBatchFolder.AutoSize = true;
            this.lblBatchFolder.Location = new System.Drawing.Point(15, 30);
            this.lblBatchFolder.Name = "lblBatchFolder";
            this.lblBatchFolder.Size = new System.Drawing.Size(99, 17);
            this.lblBatchFolder.TabIndex = 0;
            this.lblBatchFolder.Text = "Thư mục đầu ra:";
            // 
            // grpBatchInput
            // 
            this.grpBatchInput.Controls.Add(this.txtBatchContent);
            this.grpBatchInput.Controls.Add(this.grpSeqGen);
            this.grpBatchInput.Dock = System.Windows.Forms.DockStyle.Left;
            this.grpBatchInput.Location = new System.Drawing.Point(10, 55);
            this.grpBatchInput.Name = "grpBatchInput";
            this.grpBatchInput.Size = new System.Drawing.Size(470, 501);
            this.grpBatchInput.TabIndex = 1;
            this.grpBatchInput.TabStop = false;
            this.grpBatchInput.Text = "📝 Danh sách mã (Mỗi dòng 1 mã)";
            // 
            // grpSeqGen
            // 
            this.grpSeqGen.Controls.Add(this.btnGenSeq);
            this.grpSeqGen.Controls.Add(this.numSeqPadding);
            this.grpSeqGen.Controls.Add(this.lblSeqPadding);
            this.grpSeqGen.Controls.Add(this.numSeqMax);
            this.grpSeqGen.Controls.Add(this.lblSeqMax);
            this.grpSeqGen.Controls.Add(this.numSeqMin);
            this.grpSeqGen.Controls.Add(this.lblSeqMin);
            this.grpSeqGen.Controls.Add(this.txtSeqPrefix);
            this.grpSeqGen.Controls.Add(this.lblSeqPrefix);
            this.grpSeqGen.Dock = System.Windows.Forms.DockStyle.Top;
            this.grpSeqGen.Location = new System.Drawing.Point(3, 21);
            this.grpSeqGen.Name = "grpSeqGen";
            this.grpSeqGen.Size = new System.Drawing.Size(464, 130);
            this.grpSeqGen.TabIndex = 0;
            this.grpSeqGen.TabStop = false;
            this.grpSeqGen.Text = "🔢 Sinh chuỗi số tăng dần tự động";
            // 
            // btnGenSeq
            // 
            this.btnGenSeq.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(245)))), ((int)(((byte)(249)))));
            this.btnGenSeq.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenSeq.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnGenSeq.Location = new System.Drawing.Point(235, 90);
            this.btnGenSeq.Name = "btnGenSeq";
            this.btnGenSeq.Size = new System.Drawing.Size(215, 30);
            this.btnGenSeq.TabIndex = 8;
            this.btnGenSeq.Text = "✨ Sinh danh sách số tăng dần";
            this.btnGenSeq.UseVisualStyleBackColor = false;
            // 
            // numSeqPadding
            // 
            this.numSeqPadding.Location = new System.Drawing.Point(135, 93);
            this.numSeqPadding.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numSeqPadding.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numSeqPadding.Name = "numSeqPadding";
            this.numSeqPadding.Size = new System.Drawing.Size(80, 25);
            this.numSeqPadding.TabIndex = 7;
            this.numSeqPadding.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // lblSeqPadding
            // 
            this.lblSeqPadding.AutoSize = true;
            this.lblSeqPadding.Location = new System.Drawing.Point(10, 95);
            this.lblSeqPadding.Name = "lblSeqPadding";
            this.lblSeqPadding.Size = new System.Drawing.Size(121, 17);
            this.lblSeqPadding.TabIndex = 6;
            this.lblSeqPadding.Text = "Số chữ số (Padding):";
            // 
            // numSeqMax
            // 
            this.numSeqMax.Location = new System.Drawing.Point(340, 56);
            this.numSeqMax.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.numSeqMax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numSeqMax.Name = "numSeqMax";
            this.numSeqMax.Size = new System.Drawing.Size(110, 25);
            this.numSeqMax.TabIndex = 5;
            this.numSeqMax.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // lblSeqMax
            // 
            this.lblSeqMax.AutoSize = true;
            this.lblSeqMax.Location = new System.Drawing.Point(235, 58);
            this.lblSeqMax.Name = "lblSeqMax";
            this.lblSeqMax.Size = new System.Drawing.Size(94, 17);
            this.lblSeqMax.TabIndex = 4;
            this.lblSeqMax.Text = "Số kết thúc (Max):";
            // 
            // numSeqMin
            // 
            this.numSeqMin.Location = new System.Drawing.Point(135, 56);
            this.numSeqMin.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.numSeqMin.Name = "numSeqMin";
            this.numSeqMin.Size = new System.Drawing.Size(80, 25);
            this.numSeqMin.TabIndex = 3;
            this.numSeqMin.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lblSeqMin
            // 
            this.lblSeqMin.AutoSize = true;
            this.lblSeqMin.Location = new System.Drawing.Point(10, 58);
            this.lblSeqMin.Name = "lblSeqMin";
            this.lblSeqMin.Size = new System.Drawing.Size(119, 17);
            this.lblSeqMin.TabIndex = 2;
            this.lblSeqMin.Text = "Số bắt đầu (Min):";
            // 
            // txtSeqPrefix
            // 
            this.txtSeqPrefix.Location = new System.Drawing.Point(135, 23);
            this.txtSeqPrefix.Name = "txtSeqPrefix";
            this.txtSeqPrefix.Size = new System.Drawing.Size(315, 25);
            this.txtSeqPrefix.TabIndex = 1;
            this.txtSeqPrefix.Text = "BARCODE-";
            // 
            // lblSeqPrefix
            // 
            this.lblSeqPrefix.AutoSize = true;
            this.lblSeqPrefix.Location = new System.Drawing.Point(10, 26);
            this.lblSeqPrefix.Name = "lblSeqPrefix";
            this.lblSeqPrefix.Size = new System.Drawing.Size(117, 17);
            this.lblSeqPrefix.TabIndex = 0;
            this.lblSeqPrefix.Text = "Text nhập (Prefix):";
            // 
            // txtBatchContent
            // 
            this.txtBatchContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBatchContent.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBatchContent.Location = new System.Drawing.Point(3, 151);
            this.txtBatchContent.Multiline = true;
            this.txtBatchContent.Name = "txtBatchContent";
            this.txtBatchContent.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtBatchContent.Size = new System.Drawing.Size(464, 347);
            this.txtBatchContent.TabIndex = 1;
            this.txtBatchContent.Text = "CODE128-ITEM-001\r\nCODE128-ITEM-002\r\nCODE128-ITEM-003";
            // 
            // pnlBatchTopBar
            // 
            this.pnlBatchTopBar.Controls.Add(this.btnLoadFile);
            this.pnlBatchTopBar.Controls.Add(this.lblBatchHelp);
            this.pnlBatchTopBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlBatchTopBar.Location = new System.Drawing.Point(10, 10);
            this.pnlBatchTopBar.Name = "pnlBatchTopBar";
            this.pnlBatchTopBar.Size = new System.Drawing.Size(956, 45);
            this.pnlBatchTopBar.TabIndex = 0;
            // 
            // btnLoadFile
            // 
            this.btnLoadFile.Location = new System.Drawing.Point(780, 5);
            this.btnLoadFile.Name = "btnLoadFile";
            this.btnLoadFile.Size = new System.Drawing.Size(170, 35);
            this.btnLoadFile.TabIndex = 1;
            this.btnLoadFile.Text = "📂 Nhập từ file CSV/TXT";
            this.btnLoadFile.UseVisualStyleBackColor = true;
            // 
            // lblBatchHelp
            // 
            this.lblBatchHelp.AutoSize = true;
            this.lblBatchHelp.ForeColor = System.Drawing.Color.DimGray;
            this.lblBatchHelp.Location = new System.Drawing.Point(5, 14);
            this.lblBatchHelp.Name = "lblBatchHelp";
            this.lblBatchHelp.Size = new System.Drawing.Size(567, 17);
            this.lblBatchHelp.TabIndex = 0;
            this.lblBatchHelp.Text = "Nhập trực tiếp các mã vạch vào khung bên dưới hoặc nạp file .txt / .csv để sinh hàng loạt.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(245)))), ((int)(((byte)(249)))));
            this.ClientSize = new System.Drawing.Size(984, 661);
            this.Controls.Add(this.tabMain);
            this.Controls.Add(this.pnlHeader);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MinimumSize = new System.Drawing.Size(900, 600);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CodeCipher - Phần Mềm Tạo Mã Vạch & QR Code";
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.tabMain.ResumeLayout(false);
            this.tabSingle.ResumeLayout(false);
            this.splitSingle.Panel1.ResumeLayout(false);
            this.splitSingle.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitSingle)).EndInit();
            this.splitSingle.ResumeLayout(false);
            this.grpStyle.ResumeLayout(false);
            this.grpStyle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numBorderPadding)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBorderThickness)).EndInit();
            this.grpSize.ResumeLayout(false);
            this.grpSize.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numMargin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWidth)).EndInit();
            this.grpContent.ResumeLayout(false);
            this.grpContent.PerformLayout();
            this.grpType.ResumeLayout(false);
            this.pnlPreviewCard.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picPreview)).EndInit();
            this.pnlToolbar.ResumeLayout(false);
            this.pnlToolbar.PerformLayout();
            this.tabBatch.ResumeLayout(false);
            this.grpBatchLog.ResumeLayout(false);
            this.grpBatchLog.PerformLayout();
            this.grpPrintConfig.ResumeLayout(false);
            this.grpPrintConfig.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRows)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCols)).EndInit();
            this.grpBatchConfig.ResumeLayout(false);
            this.grpBatchConfig.PerformLayout();
            this.grpBatchInput.ResumeLayout(false);
            this.grpBatchInput.PerformLayout();
            this.grpSeqGen.ResumeLayout(false);
            this.grpSeqGen.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSeqPadding)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSeqMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSeqMin)).EndInit();
            this.pnlBatchTopBar.ResumeLayout(false);
            this.pnlBatchTopBar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblHeaderTitle;
        private System.Windows.Forms.Label lblHeaderSubtitle;
        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabSingle;
        private System.Windows.Forms.TabPage tabBatch;
        private System.Windows.Forms.SplitContainer splitSingle;
        private System.Windows.Forms.GroupBox grpType;
        private System.Windows.Forms.ComboBox cmbBarcodeType;
        private System.Windows.Forms.GroupBox grpContent;
        private System.Windows.Forms.TextBox txtContent;
        private System.Windows.Forms.Label lblContentHint;
        private System.Windows.Forms.GroupBox grpSize;
        private System.Windows.Forms.NumericUpDown numWidth;
        private System.Windows.Forms.Label lblWidth;
        private System.Windows.Forms.NumericUpDown numHeight;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.NumericUpDown numMargin;
        private System.Windows.Forms.Label lblMargin;
        private System.Windows.Forms.GroupBox grpStyle;
        private System.Windows.Forms.Button btnForeColor;
        private System.Windows.Forms.Panel pnlForeColorPreview;
        private System.Windows.Forms.Button btnBackColor;
        private System.Windows.Forms.Panel pnlBackColorPreview;
        private System.Windows.Forms.Label lblTextPosition;
        private System.Windows.Forms.ComboBox cmbTextPosition;
        private System.Windows.Forms.CheckBox chkIncludeBorder;
        private System.Windows.Forms.NumericUpDown numBorderThickness;
        private System.Windows.Forms.Button btnBorderColor;
        private System.Windows.Forms.Panel pnlBorderColorPreview;
        private System.Windows.Forms.Label lblBorderPadding;
        private System.Windows.Forms.NumericUpDown numBorderPadding;
        private System.Windows.Forms.Panel pnlPreviewCard;
        private System.Windows.Forms.PictureBox picPreview;
        private System.Windows.Forms.FlowLayoutPanel pnlToolbar;
        private System.Windows.Forms.Button btnCopy;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Panel pnlBatchTopBar;
        private System.Windows.Forms.Label lblBatchHelp;
        private System.Windows.Forms.Button btnLoadFile;
        private System.Windows.Forms.GroupBox grpBatchInput;
        private System.Windows.Forms.GroupBox grpSeqGen;
        private System.Windows.Forms.Label lblSeqPrefix;
        private System.Windows.Forms.TextBox txtSeqPrefix;
        private System.Windows.Forms.Label lblSeqMin;
        private System.Windows.Forms.NumericUpDown numSeqMin;
        private System.Windows.Forms.Label lblSeqMax;
        private System.Windows.Forms.NumericUpDown numSeqMax;
        private System.Windows.Forms.Label lblSeqPadding;
        private System.Windows.Forms.NumericUpDown numSeqPadding;
        private System.Windows.Forms.Button btnGenSeq;
        private System.Windows.Forms.TextBox txtBatchContent;
        private System.Windows.Forms.GroupBox grpBatchConfig;
        private System.Windows.Forms.Label lblBatchFolder;
        private System.Windows.Forms.TextBox txtBatchFolder;
        private System.Windows.Forms.Button btnBrowseFolder;
        private System.Windows.Forms.Label lblBatchExt;
        private System.Windows.Forms.ComboBox cmbBatchExt;
        private System.Windows.Forms.Button btnStartBatch;
        private System.Windows.Forms.GroupBox grpPrintConfig;
        private System.Windows.Forms.Label lblPaperSize;
        private System.Windows.Forms.ComboBox cmbPaperSize;
        private System.Windows.Forms.Label lblColsRows;
        private System.Windows.Forms.NumericUpDown numCols;
        private System.Windows.Forms.Label lblTimes;
        private System.Windows.Forms.NumericUpDown numRows;
        private System.Windows.Forms.CheckBox chkPrintGrid;
        private System.Windows.Forms.Button btnPrintBatchPreview;
        private System.Windows.Forms.GroupBox grpBatchLog;
        private System.Windows.Forms.TextBox txtBatchLog;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}
